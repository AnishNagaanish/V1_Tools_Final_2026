import os
from qgis.core import *
from qgis.gui import *
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtCore import *
from collections import defaultdict, deque
import math
import re
import processing
import traceback

# ========================== TOOL ==========================
class PointTool(QgsMapToolEmitPoint):
    canvasClicked = pyqtSignal(QgsPointXY)
    def __init__(self, canvas):
        super().__init__(canvas)
    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.canvasClicked.emit(point)

# ========================== DIALOG UI ==========================
class FTTHPlannerDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("FTTH Planner v1.0 (HLD/LLD)")
        self.setMinimumWidth(1100)
        self.setMinimumHeight(750)
        self.houses_data = []
        self.tobys_data = []
        self.drops_data = []
        self.crs = None
        self.pick_tool = None
        self.setup_ui()
        self.auto_select_layers()

    def setup_ui(self):
        self.setStyleSheet("QDialog{background-color:#f0f2f5;} QGroupBox{background-color:white;border:1px solid #dfe6e9;border-radius:8px;margin-top:1.2em;font-weight:bold;padding:15px;} QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox{padding:4px;border:1px solid #b2bec3;border-radius:4px;background:#ffffff;color:#2d3436;} QPushButton{border-radius:6px;padding:8px;color:white;font-weight:bold;border:none;} QLabel{color:#636e72;font-weight:500;}")
        self.main_layout = QHBoxLayout(self)
        left_widget = QWidget(); left_layout = QVBoxLayout(left_widget)
        
        # 1. INPUTS
        grp_in = QGroupBox("1. DATA INPUTS"); grp_in.setStyleSheet("QGroupBox { border-top: 4px solid #3498db; }"); l_in = QFormLayout()
        self.addr_combo = QgsMapLayerComboBox(); self.addr_combo.setFilters(QgsMapLayerProxyModel.PointLayer); self.addr_combo.layerChanged.connect(self.on_addr_change)
        l_in.addRow("Addresses:", self.addr_combo)
        h_addr = QHBoxLayout(); self.addr_street_field = QgsFieldComboBox(); self.addr_id_field = QgsFieldComboBox()
        h_addr.addWidget(QLabel("St:")); h_addr.addWidget(self.addr_street_field); h_addr.addWidget(QLabel("ID:")); h_addr.addWidget(self.addr_id_field); l_in.addRow(h_addr)
        self.street_combo = QgsMapLayerComboBox(); self.street_combo.setFilters(QgsMapLayerProxyModel.LineLayer); self.street_combo.layerChanged.connect(self.on_street_change)
        l_in.addRow("Streets:", self.street_combo); self.street_name_field = QgsFieldComboBox(); l_in.addRow("Name Fld:", self.street_name_field)
        self.parcel_combo = QgsMapLayerComboBox(); self.parcel_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer); l_in.addRow("Parcels:", self.parcel_combo)
        self.area_combo = QgsMapLayerComboBox(); self.area_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer); self.area_combo.setAllowEmptyLayer(True); self.area_combo.layerChanged.connect(self.on_area_change)
        l_in.addRow("Boundary:", self.area_combo)
        h_zone = QHBoxLayout(); self.area_field = QgsFieldComboBox(); self.area_field.fieldChanged.connect(self.load_areas); self.area_select = QComboBox()
        h_zone.addWidget(self.area_field); h_zone.addWidget(self.area_select); l_in.addRow("Zone:", h_zone)
        h_drop = QHBoxLayout(); self.drop_bound_combo = QgsMapLayerComboBox(); self.drop_bound_combo.setFilters(QgsMapLayerProxyModel.PolygonLayer); self.drop_bound_combo.setAllowEmptyLayer(True)
        self.btn_pick_drop = QPushButton("Pick"); self.btn_pick_drop.setStyleSheet("background-color: #95a5a6; max-width: 50px;"); self.btn_pick_drop.clicked.connect(self.activate_pick_tool)
        h_drop.addWidget(self.drop_bound_combo); h_drop.addWidget(self.btn_pick_drop); l_in.addRow("Drop Zone:", h_drop)
        self.fdh_combo = QgsMapLayerComboBox(); self.fdh_combo.setFilters(QgsMapLayerProxyModel.PointLayer); self.fdh_combo.setAllowEmptyLayer(True); l_in.addRow("FDH Loc:", self.fdh_combo)
        grp_in.setLayout(l_in); left_layout.addWidget(grp_in)
        
        # 2. SETTINGS
        grp_set = QGroupBox("2. DESIGN RULES"); grp_set.setStyleSheet("QGroupBox { border-top: 4px solid #9b59b6; }"); l_set = QFormLayout()
        self.toby_offset = QDoubleSpinBox(); self.toby_offset.setRange(0, 100); self.toby_offset.setValue(15); l_set.addRow("Offset (ft):", self.toby_offset)
        self.cluster_gap = QSpinBox(); self.cluster_gap.setRange(50, 2000); self.cluster_gap.setValue(200); l_set.addRow("Max Gap:", self.cluster_gap)
        self.gap_threshold = QSpinBox(); self.gap_threshold.setRange(50, 500); self.gap_threshold.setValue(120); l_set.addRow("Grp Dist:", self.gap_threshold)
        grp_set.setLayout(l_set); left_layout.addWidget(grp_set); left_layout.addStretch()
        
        # RIGHT COLUMN
        right_widget = QWidget(); right_layout = QVBoxLayout(right_widget)
        grp_out = QGroupBox("3. OUTPUT TARGETS"); grp_out.setStyleSheet("QGroupBox { border-top: 4px solid #2ecc71; }"); l_out = QVBoxLayout()
        h_rad = QHBoxLayout(); self.rb_new = QRadioButton("New Layers"); self.rb_append = QRadioButton("Append"); self.rb_new.setChecked(True)
        h_rad.addWidget(self.rb_new); h_rad.addWidget(self.rb_append); l_out.addLayout(h_rad)
        self.target_widget = QWidget(); l_t = QFormLayout()
        self.target_toby = QgsMapLayerComboBox(); self.target_toby.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.target_drop = QgsMapLayerComboBox(); self.target_drop.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.target_dist = QgsMapLayerComboBox(); self.target_dist.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.target_conduit_dist = QgsMapLayerComboBox(); self.target_conduit_dist.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.target_conduit_drop = QgsMapLayerComboBox(); self.target_conduit_drop.setFilters(QgsMapLayerProxyModel.LineLayer)
        l_t.addRow("Toby:", self.target_toby); l_t.addRow("Drop:", self.target_drop); l_t.addRow("Dist:", self.target_dist)
        l_t.addRow("Cond D:", self.target_conduit_dist); l_t.addRow("Cond H:", self.target_conduit_drop)
        self.target_widget.setLayout(l_t); self.target_widget.setVisible(False); self.rb_append.toggled.connect(self.target_widget.setVisible); l_out.addWidget(self.target_widget)
        grp_out.setLayout(l_out); right_layout.addWidget(grp_out)
        
        grp_con = QGroupBox("4. CONDUIT"); grp_con.setStyleSheet("QGroupBox { border-top: 4px solid #e67e22; }"); l_c = QFormLayout()
        self.conduit_dist_combo = QgsMapLayerComboBox(); self.conduit_dist_combo.setFilters(QgsMapLayerProxyModel.LineLayer); l_c.addRow("Network:", self.conduit_dist_combo)
        self.conduit_toby_combo = QgsMapLayerComboBox(); self.conduit_toby_combo.setFilters(QgsMapLayerProxyModel.PointLayer); l_c.addRow("Tobys:", self.conduit_toby_combo)
        self.conduit_drops_combo = QgsMapLayerComboBox(); self.conduit_drops_combo.setFilters(QgsMapLayerProxyModel.LineLayer); l_c.addRow("Drops:", self.conduit_drops_combo)
        self.conduit_snap = QDoubleSpinBox(); self.conduit_snap.setRange(1, 50); self.conduit_snap.setValue(5); l_c.addRow("Snap:", self.conduit_snap)
        grp_con.setLayout(l_c); right_layout.addWidget(grp_con)
        
        self.log = QTextEdit(); self.log.setReadOnly(True); self.log.setStyleSheet("background-color: #2d3436; color: #00cec9; font-family: Consolas; font-size: 11px; border: 2px solid #b2bec3;")
        right_layout.addWidget(self.log)
        
        h_act1 = QHBoxLayout(); self.btn_step1 = QPushButton("1. GENERATE TOBYS"); self.btn_step1.setStyleSheet("background-color: #2980b9;")
        self.btn_step1.clicked.connect(self.run_step_1_tobys); self.btn_step2 = QPushButton("2. DROPS"); self.btn_step2.setStyleSheet("background-color: #8e44ad;")
        self.btn_step2.clicked.connect(self.run_step_2_drops); h_act1.addWidget(self.btn_step1); h_act1.addWidget(self.btn_step2)
        h_act2 = QHBoxLayout(); self.btn_step3 = QPushButton("3. ARCHITECT"); self.btn_step3.setStyleSheet("background-color: #27ae60;")
        self.btn_step3.clicked.connect(self.run_step_3_architect); self.btn_step5 = QPushButton("4. CONDUIT"); self.btn_step5.setStyleSheet("background-color: #d35400;")
        self.btn_step5.clicked.connect(self.run_step_5_conduits); h_act2.addWidget(self.btn_step3); h_act2.addWidget(self.btn_step5)
        self.btn_reset = QPushButton("RESET ALL"); self.btn_reset.setStyleSheet("background-color: #c0392b;"); self.btn_reset.clicked.connect(self.reset_data)
        right_layout.addLayout(h_act1); right_layout.addLayout(h_act2); right_layout.addWidget(self.btn_reset)
        self.main_layout.addWidget(left_widget, 40); self.main_layout.addWidget(right_widget, 60)
        self.on_addr_change(); self.on_street_change(); self.on_area_change()

    # --- UI EVENT HANDLERS ---
    def on_addr_change(self): self.addr_id_field.setLayer(self.addr_combo.currentLayer()); self.addr_street_field.setLayer(self.addr_combo.currentLayer())
    def on_street_change(self): self.street_name_field.setLayer(self.street_combo.currentLayer())
    def on_area_change(self): self.area_field.setLayer(self.area_combo.currentLayer()); self.load_areas(None)
    def load_areas(self, fld):
        self.area_select.clear(); self.area_select.addItem("-- Full Extent --", None); lyr = self.area_combo.currentLayer()
        if lyr and self.area_field.currentField():
            names = sorted(set([str(f[self.area_field.currentField()]) for f in lyr.getFeatures() if f[self.area_field.currentField()]]))
            for n in names: self.area_select.addItem(n, n)
    def activate_pick_tool(self):
        lyr = self.drop_bound_combo.currentLayer()
        if not lyr: return self.msg("Select Drop Layer first.")
        self.msg(">> Click polygon..."); self.hide(); self.pick_tool = PointTool(self.iface.mapCanvas()); self.pick_tool.canvasClicked.connect(self.on_poly_picked); self.iface.mapCanvas().setMapTool(self.pick_tool)
    def on_poly_picked(self, point):
        lyr = self.drop_bound_combo.currentLayer()
        if lyr:
            req = QgsFeatureRequest().setFilterRect(QgsGeometry.fromPointXY(point).buffer(1, 5).boundingBox())
            lyr.removeSelection(); ids = [f.id() for f in lyr.getFeatures(req) if f.geometry().contains(point)]
            if ids: lyr.selectByIds(ids); self.msg(f">> ID: {ids[0]}")
        self.iface.mapCanvas().unsetMapTool(self.pick_tool); self.pick_tool = None; self.show()
    def msg(self, t): self.log.append(t); QApplication.processEvents()
    def reset_data(self): self.houses_data = []; self.tobys_data = []; self.drops_data = []; self.log.clear(); self.msg("Data Reset.")
    def auto_select_layers(self):
        layers = list(QgsProject.instance().mapLayers().values())
        def m(cb, k):
            if cb.currentLayer(): return
            for l in layers:
                if l.type()==QgsMapLayer.VectorLayer and any(x in l.name().lower() for x in k):
                    if (cb.filters() & QgsMapLayerProxyModel.PointLayer and l.geometryType()==QgsWkbTypes.PointGeometry) or (cb.filters() & QgsMapLayerProxyModel.LineLayer and l.geometryType()==QgsWkbTypes.LineGeometry) or (cb.filters() & QgsMapLayerProxyModel.PolygonLayer and l.geometryType()==QgsWkbTypes.PolygonGeometry): cb.setLayer(l); return
        m(self.addr_combo, ['address', 'structure']); m(self.street_combo, ['street', 'road']); m(self.parcel_combo, ['parcel', 'lot']); m(self.area_combo, ['fdh_bound', 'zone']); m(self.fdh_combo, ['fdh', 'hub']); m(self.target_toby, ['proposed_toby']); m(self.target_dist, ['distribution', 'dist_net'])

    # --- HELPER FUNCTIONS ---
    def get_boundary(self):
        lyr = self.area_combo.currentLayer(); 
        if not lyr: return None
        nm = self.area_select.currentData(); fld = self.area_field.currentField()
        if not nm: return None
        for f in lyr.getFeatures(): 
            if str(f[fld]) == nm: return f.geometry()
        return None
    def load_parcels(self, lyr, bbox, bnd):
        idx = QgsSpatialIndex(); feats = []
        for pid, f in enumerate(lyr.getFeatures(QgsFeatureRequest().setFilterRect(bbox))):
            g = f.geometry()
            if bnd and not g.intersects(bnd): continue
            feats.append((g, f.id())); fi = QgsFeature(pid); fi.setGeometry(g); idx.addFeature(fi)
        return feats, idx
    def load_streets(self, lyr, bbox, bnd):
        idx = QgsSpatialIndex(); streets = {}; nm = self.street_name_field.currentField()
        for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(bbox)):
            g = f.geometry()
            if g.isEmpty() or (bnd and not g.intersects(bnd)): continue
            fid = f.id(); streets[fid] = {'geom': g, 'name': str(f[nm]) if nm and f[nm] else ""}; fi = QgsFeature(fid); fi.setGeometry(g); idx.addFeature(fi)
        return streets, idx
    def extract_by_location(self, layer, boundary):
        out = QgsVectorLayer(f"MultiLineString?crs={layer.crs().authid()}", "Ex", "memory"); out.dataProvider().addAttributes(layer.fields()); out.updateFields()
        for f in layer.getFeatures(QgsFeatureRequest().setFilterRect(boundary.boundingBox())):
            if f.geometry().intersects(boundary): 
                g = f.geometry()
                if not g.isMultipart(): g = QgsGeometry.fromMultiPolylineXY([g.asPolyline()])
                nf = QgsFeature(f); nf.setGeometry(g); out.dataProvider().addFeature(nf)
        return out
    
    def normalize_street(self, name): return re.sub(r'[.,#\-]', ' ', str(name).upper().strip()) if name else ""
    def midpoint(self, p1, p2): return QgsPointXY((p1.x()+p2.x())/2, (p1.y()+p2.y())/2)
    def get_road_side(self, pt, p1, p2): return 'left' if (p2.x()-p1.x())*(pt.y()-p1.y()) - (p2.y()-p1.y())*(pt.x()-p1.x()) > 0 else 'right'
    
    def get_street_key_words(self, name):
        if not name: return set()
        rem = {'N','S','E','W','NE','NW','SE','SW','ST','STREET','RD','ROAD','DR','DRIVE','AVE','BLVD','LN','CT','CIR','PL','WAY'}
        return {w for w in name.split() if w and w not in rem and len(w) > 1}
    
    def to_crs_units(self, val): return val * 0.3048 if self.crs and self.crs.mapUnits() != QgsUnitTypes.DistanceFeet else val
    def setup_measurement(self, crs): self.crs = crs
    
    def enforce_flow_direction(self, geom, source_pt):
        parts = []
        if geom.isMultipart(): parts = geom.asMultiPolyline()
        else: parts = [geom.asPolyline()]
        oriented_parts = []; source_geom = QgsGeometry.fromPointXY(source_pt)
        for poly in parts:
            if len(poly) < 2: continue
            dist_start = source_geom.distance(QgsGeometry.fromPointXY(poly[0]))
            dist_end = source_geom.distance(QgsGeometry.fromPointXY(poly[-1]))
            if dist_start > dist_end: oriented_parts.append(list(reversed(poly)))
            else: oriented_parts.append(poly)
        if len(oriented_parts) == 1: return QgsGeometry.fromPolylineXY(oriented_parts[0])
        else: return QgsGeometry.fromMultiPolylineXY(oriented_parts)
    
    def orient_network_flow(self, lines, fdh_pt):
        # 1. Collect and Noding (This splits distribution lines at intersections)
        try:
            combined = QgsGeometry.collectGeometry(lines)
            union_geom = combined.unaryUnion() # Force split
            if union_geom.isMultipart(): parts = union_geom.asMultiPolyline()
            else: parts = [union_geom.asPolyline()]
        except: return lines 
        
        # 2. Build Graph
        def pk(pt): return (round(pt.x(), 2), round(pt.y(), 2))
        adj = defaultdict(list); segments = {} 
        for i, poly in enumerate(parts):
            if len(poly) < 2: continue
            u, v = pk(poly[0]), pk(poly[-1])
            adj[u].append((v, i)); adj[v].append((u, i)); segments[i] = poly
            
        # 3. BFS from FDH
        start_node = None; min_d = float('inf'); fdh_g = QgsGeometry.fromPointXY(fdh_pt)
        all_nodes = list(adj.keys())
        for node_tup in all_nodes:
            pt = QgsPointXY(node_tup[0], node_tup[1]); d = fdh_g.distance(QgsGeometry.fromPointXY(pt))
            if d < min_d: min_d = d; start_node = node_tup
            
        queue = deque([start_node]); visited_segments = set(); oriented_lines = []
        while queue:
            curr = queue.popleft()
            for neighbor, seg_id in adj[curr]:
                if seg_id not in visited_segments:
                    visited_segments.add(seg_id); poly = segments[seg_id]
                    p_start, p_end = pk(poly[0]), pk(poly[-1])
                    if p_start == curr: oriented_lines.append(QgsGeometry.fromPolylineXY(poly))
                    else: oriented_lines.append(QgsGeometry.fromPolylineXY(list(reversed(poly))))
                    queue.append(neighbor)
        
        # 4. Fallback for Islands
        for i, poly in segments.items():
            if i not in visited_segments:
                p_start, p_end = poly[0], poly[-1]
                ds = fdh_g.distance(QgsGeometry.fromPointXY(p_start))
                de = fdh_g.distance(QgsGeometry.fromPointXY(p_end))
                if ds > de: oriented_lines.append(QgsGeometry.fromPolylineXY(list(reversed(poly))))
                else: oriented_lines.append(QgsGeometry.fromPolylineXY(poly))
        return oriented_lines

    def _apply_conduit_styling(self, layer):
        cats = []; colors = {'CONDUIT-MD-24W': ('#e74c3c', 2.5), 'CONDUIT-MD-12W': ('#f39c12', 2.0), 'CONDUIT-MD-2W': ('#3498db', 1.5), 'CONDUIT-MD-1W': ('#2ecc71', 1.0)}
        for t, (c, w) in colors.items(): sym = QgsLineSymbol.createSimple({'color': c, 'width': str(w)}); cats.append(QgsRendererCategory(t, sym, t))
        layer.setRenderer(QgsCategorizedSymbolRenderer('TYPE', cats))

    def match_addresses(self, lyr, streets, st_idx, parcels, parcel_idx, bbox, bnd, search_rad):
        houses = []; stats = {'failed': 0}; id_fld = self.addr_id_field.currentField(); st_fld = self.addr_street_field.currentField(); street_map = defaultdict(list)
        for sid, st_data in streets.items():
            for kw in self.get_street_key_words(self.normalize_street(st_data.get('name', ''))): street_map[kw].append(sid)
        for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(bbox)):
            geom = f.geometry()
            if not geom or (bnd and not bnd.contains(geom)): continue
            pt = QgsPointXY(geom.asPoint()); pcl_geom = None
            for c in parcel_idx.intersects(QgsGeometry.fromPointXY(pt).buffer(5, 5).boundingBox()):
                if c < len(parcels) and parcels[c][0].contains(QgsGeometry.fromPointXY(pt)): pcl_geom = parcels[c][0]; break
            addr_st = str(f[st_fld]) if st_fld and f[st_fld] else ""; addr_kw = self.get_street_key_words(self.normalize_street(addr_st))
            best_sid, min_dist, best_snap = None, float('inf'), None
            cands = set(); [cands.update(street_map.get(kw, [])) for kw in addr_kw]
            for sid in cands:
                snap = self.closest_point_on_line(pt, streets[sid]['geom'])
                if snap:
                    d = math.sqrt(pt.sqrDist(snap[0]))
                    if d < min_dist and d <= search_rad*5: min_dist, best_sid, best_snap = d, sid, snap
            if best_sid is None:
                for sid in st_idx.nearestNeighbor(pt, 5):
                    if sid not in streets: continue
                    snap = self.closest_point_on_line(pt, streets[sid]['geom'])
                    if snap:
                        d = math.sqrt(pt.sqrDist(snap[0]))
                        if d < min_dist and d <= search_rad: min_dist, best_sid, best_snap = d, sid, snap
            if best_sid is not None:
                side = self.get_road_side(pt, best_snap[1], best_snap[2])
                houses.append({'id': f[id_fld] if id_fld else f.id(), 'pt': pt, 'snap_pt': best_snap[0], 'street_fid': best_sid, 'street_geom': streets[best_sid]['geom'], 'road_side': side, 'parcel_geom': pcl_geom, 'matched_street': streets[best_sid].get('name', ''), 'address_street': addr_st})
            else: stats['failed'] += 1
        return houses, stats
    def group_houses(self, houses, gap):
        for h in houses: h['station'] = h['street_geom'].lineLocatePoint(QgsGeometry.fromPointXY(h['snap_pt']))
        raw = defaultdict(list)
        for h in houses: raw[(h['street_fid'], h['road_side'], self.normalize_street(h['matched_street']))].append(h)
        groups = []
        for key, hlist in raw.items():
            hlist.sort(key=lambda x: x['station']); curr = []
            for h in hlist:
                if not curr: curr.append(h)
                elif abs(h['station'] - curr[-1]['station']) > gap: groups.append({'key': key, 'houses': curr}); curr = [h]
                else: curr.append(h)
            if curr: groups.append({'key': key, 'houses': curr})
        return groups
    def create_tobys(self, groups, offset, boundary):
        tobys = []; tid = 1
        for g in groups:
            hlist = g['houses']
            for i in range(0, len(hlist), 2):
                chunk = hlist[i:i+2]; 
                if not chunk: continue
                neighbor = None
                if len(chunk) == 1:
                    if i + 1 < len(hlist): neighbor = hlist[i+1]
                    elif i - 1 >= 0: neighbor = hlist[i-1]
                loc, base = self.calc_toby_pos(chunk, chunk[0]['street_geom'], offset, boundary, neighbor)
                tobys.append({'id': tid, 'location': loc, 'houses': chunk, 'street_fid': g['key'][0], 'road_side': g['key'][1], 'addresses_served': ", ".join([str(h['id']) for h in chunk]), 'house_count': len(chunk), 'street_name': chunk[0].get('matched_street', '')}); tid += 1
        return tobys
    
    def calc_toby_pos(self, houses, street, offset, boundary, neighbor=None):
        base_pt = None
        if len(houses) == 2:
            p1 = houses[0].get('parcel_geom'); p2 = houses[1].get('parcel_geom')
            if p1 and p2: base_pt = self.find_shared_boundary_point(p1, p2, street)
            if not base_pt: base_pt = self.midpoint(houses[0]['pt'], houses[1]['pt'])
        elif len(houses) == 1:
            p1 = houses[0].get('parcel_geom')
            if neighbor:
                p2 = neighbor.get('parcel_geom')
                if p1 and p2: base_pt = self.find_shared_boundary_point(p1, p2, street)
            if not base_pt and p1: base_pt = self.find_parcel_corner_nearest_street(p1, street)
            if not base_pt: base_pt = houses[0]['pt']
        res = self.closest_point_on_line(base_pt, street)
        if res:
            s_pt = res[0]; dx, dy = base_pt.x() - s_pt.x(), base_pt.y() - s_pt.y(); L = math.sqrt(dx*dx + dy*dy)
            if L > 0: ux, uy = dx/L, dy/L; final = QgsPointXY(s_pt.x() + ux*offset, s_pt.y() + uy*offset)
            else: final = s_pt
        else: final = base_pt
        if boundary and not boundary.contains(QgsGeometry.fromPointXY(final)): return base_pt, base_pt
        return final, base_pt
    def find_shared_boundary_point(self, p1, p2, street):
        try:
            l1 = p1.convertToType(QgsWkbTypes.LineGeometry); l2 = p2.convertToType(QgsWkbTypes.LineGeometry); inter = l1.intersection(l2)
            if inter.isEmpty(): inter = l1.buffer(0.1, 5).intersection(l2)
            verts = []
            if inter.type() == QgsWkbTypes.PointGeometry: verts = inter.asMultiPoint() if inter.isMultipart() else [inter.asPoint()]
            elif inter.type() == QgsWkbTypes.LineGeometry:
                parts = inter.asMultiPolyline() if inter.isMultipart() else [inter.asPolyline()]; [verts.extend(p) for p in parts]
            best = None; min_d = float('inf')
            for v in verts:
                pt = QgsPointXY(v.x(), v.y()) if isinstance(v, QgsPoint) else v
                d = street.distance(QgsGeometry.fromPointXY(pt))
                if d < min_d: min_d = d; best = pt
            return best
        except: return None
    def find_parcel_corner_nearest_street(self, pcl, street):
        try:
            verts = []; 
            if pcl.isMultipart(): [verts.extend(p[0]) for p in pcl.asMultiPolygon()]
            else: verts.extend(pcl.asPolygon()[0])
            best = None; min_d = float('inf')
            for v in verts:
                pt = QgsPointXY(v.x(), v.y()); d = street.distance(QgsGeometry.fromPointXY(pt))
                if d < min_d: min_d = d; best = pt
            return best
        except: return None
    def closest_point_on_line(self, pt, line):
        min_d, res = float('inf'), None; parts = line.asMultiPolyline() if line.isMultipart() else [line.asPolyline()]
        for part in parts:
            for i in range(len(part) - 1):
                p1, p2 = part[i], part[i+1]; dx, dy = p2.x() - p1.x(), p2.y() - p1.y(); l2 = dx*dx + dy*dy
                if l2 == 0: continue
                t = max(0, min(1, ((pt.x()-p1.x())*dx + (pt.y()-p1.y())*dy) / l2))
                proj = QgsPointXY(p1.x() + t*dx, p1.y() + t*dy); d = math.sqrt(pt.sqrDist(proj))
                if d < min_d: min_d, res = d, (proj, p1, p2, t)
        return res
    def extract_curve_between(self, street_geom, start_dist, end_dist, p_start, p_end):
        if abs(start_dist - end_dist) < 0.1: return None 
        reverse = False
        if start_dist > end_dist: start_dist, end_dist = end_dist, start_dist; p_start, p_end = p_end, p_start; reverse = True
        points = [p_start]; step = 15.0; curr = start_dist + step; street_p1 = street_geom.interpolate(start_dist).asPoint(); street_p2 = street_geom.interpolate(end_dist).asPoint()
        while curr < end_dist:
            pt_on_street = street_geom.interpolate(curr).asPoint(); total_len = end_dist - start_dist
            if total_len <= 0: break
            t = (curr - start_dist) / total_len; v1x = p_start.x() - street_p1.x(); v1y = p_start.y() - street_p1.y(); v2x = p_end.x() - street_p2.x(); v2y = p_end.y() - street_p2.y()
            vx = v1x + t * (v2x - v1x); vy = v1y + t * (v2y - v1y); new_pt = QgsPointXY(pt_on_street.x() + vx, pt_on_street.y() + vy)
            points.append(new_pt); curr += step
        points.append(p_end)
        if reverse: points.reverse()
        return QgsGeometry.fromPolylineXY(points).simplify(0.25)

    # --- EXECUTION STEPS ---
    def run_step_1_tobys(self):
        self.reset_data(); self.msg("Step 1: Placing Tobys..."); addr_lyr = self.addr_combo.currentLayer(); st_lyr = self.street_combo.currentLayer(); pcl_lyr = self.parcel_combo.currentLayer()
        if not all([addr_lyr, st_lyr, pcl_lyr]): return self.msg("ERROR: Missing input layers!")
        self.calc_crs = addr_lyr.crs(); self.setup_measurement(self.calc_crs)
        self.boundary = self.get_boundary(); bbox = self.boundary.boundingBox() if self.boundary else addr_lyr.extent()
        if not self.boundary: bbox.grow(500)
        parcels, parcel_idx = self.load_parcels(pcl_lyr, bbox, self.boundary)
        streets, st_idx = self.load_streets(st_lyr, bbox, self.boundary)
        if not streets: return self.msg("ERROR: No streets found!")
        self.houses_data, stats = self.match_addresses(addr_lyr, streets, st_idx, parcels, parcel_idx, bbox, self.boundary, self.to_crs_units(500))
        self.msg(f"   Matched: {len(self.houses_data)} | Failed: {stats['failed']}")
        if not self.houses_data: return self.msg("ERROR: No houses matched.")
        groups = self.group_houses(self.houses_data, self.to_crs_units(self.gap_threshold.value()))
        self.tobys_data = self.create_tobys(groups, self.to_crs_units(self.toby_offset.value()), self.boundary)
        self.msg(f"   Generated {len(self.tobys_data)} Tobys.")
        project_crs = QgsProject.instance().crs()
        if self.rb_append.isChecked(): self.append_to_layer(self.target_toby.currentLayer(), self.tobys_data, 'toby')
        else: self.create_layer_tobys(self.tobys_data, self.calc_crs, project_crs)
        self.create_layer_houses(self.houses_data, self.calc_crs, project_crs); self.msg("Step 1 Complete!")

    def run_step_2_drops(self):
        self.msg("\nStep 2: Creating Drops..."); 
        if not self.tobys_data: return self.msg("ERROR: Run Step 1 first!")
        drops_meta = []
        for t in self.tobys_data:
            toby_loc = t['location']; t_houses = t['houses']
            for h in t_houses:
                line = QgsGeometry.fromPolylineXY([toby_loc, h['pt']])
                drops_meta.append({'geom': line, 'from_toby_id': t['id'], 'to_address': str(h['id']), 'street_name': h.get('matched_street', '')})
        project_crs = QgsProject.instance().crs()
        if self.rb_append.isChecked(): self.append_to_layer(self.target_drop.currentLayer(), drops_meta, 'drop')
        else: self.create_layer_drops(drops_meta, self.calc_crs, project_crs)
        self.drops_data = drops_meta; self.msg(f"Step 2 Complete! ({len(drops_meta)} drops)")

    def run_step_3_architect(self):
        if not self.tobys_data: return self.msg("ERROR: Run Step 1 first."); self.msg("\nStep 3: Architect...")
        st_lyr = self.street_combo.currentLayer(); fdh_lyr = self.fdh_combo.currentLayer()
        boundary = self.get_boundary(); calc_crs = st_lyr.crs()
        if not boundary: return self.msg("ERROR: Boundary required!")
        fdh_pt = None
        if fdh_lyr:
            for f in fdh_lyr.getFeatures():
                if boundary.contains(f.geometry()): fdh_pt = f.geometry().asPoint(); break
        if not fdh_pt: return self.msg("ERROR: No FDH found inside boundary!")
        street_geoms = {}; active_streets = set()
        for f in st_lyr.getFeatures():
            if f.geometry().intersects(boundary): street_geoms[f.id()] = f.geometry()
        st_toby_map = defaultdict(lambda: {'left': [], 'right': []})
        for t in self.tobys_data:
            sid = t.get('street_fid'); side = t.get('road_side')
            if sid in street_geoms and side:
                active_streets.add(sid); st_geom = street_geoms[sid]
                dist = st_geom.lineLocatePoint(st_geom.nearestPoint(QgsGeometry.fromPointXY(t['location'])))
                t['station'] = dist; st_toby_map[sid][side].append(t)
        network_lines = []; cluster_gap_limit = self.to_crs_units(self.cluster_gap.value())
        dominant_spine_points = defaultdict(list); crossing_tobys = defaultdict(list); main_line_geoms = defaultdict(list)
        for sid, sides in st_toby_map.items():
            st_geom = street_geoms[sid]; sides['left'].sort(key=lambda x: x['station']); sides['right'].sort(key=lambda x: x['station'])
            l_homes = sum(t.get('house_count', 1) for t in sides['left']); r_homes = sum(t.get('house_count', 1) for t in sides['right'])
            if l_homes == 0 and r_homes == 0: continue
            dom_side = 'left' if l_homes >= r_homes else 'right'; nd_side = 'right' if dom_side == 'left' else 'left'
            dom_tobys = sides[dom_side]; nd_tobys = sides[nd_side]
            if not dom_tobys and nd_tobys:
                for t in nd_tobys:
                    pt_loc = t['location']; stat = t['station']; center_pt = st_geom.interpolate(stat).asPoint()
                    dominant_spine_points[sid].append({'station': stat, 'pt': center_pt, 'type': 'virtual'})
            else:
                for t in dom_tobys: dominant_spine_points[sid].append({'station': t['station'], 'pt': t['location'], 'type': 'toby'})
            if nd_tobys:
                clusters = []; current_cluster = []; current_homes = 0
                for i, t in enumerate(nd_tobys):
                    hc = t.get('house_count', 1); dist_ok = True
                    if current_cluster:
                        if abs(t['station'] - current_cluster[-1]['station']) > cluster_gap_limit: dist_ok = False 
                    if (current_homes + hc <= 6) and dist_ok: current_cluster.append(t); current_homes += hc
                    else:
                        if current_cluster: clusters.append(current_cluster)
                        current_cluster = [t]; current_homes = hc
                if current_cluster: clusters.append(current_cluster)
                for cl in clusters:
                    if len(cl) > 1:
                        for i in range(len(cl) - 1):
                            t1, t2 = cl[i], cl[i+1]
                            seg = self.extract_curve_between(st_geom, t1['station'], t2['station'], t1['location'], t2['location'])
                            if seg: network_lines.append(seg)
                    mid_idx = len(cl) // 2; crossing_tobys[sid].append(cl[mid_idx])
        for sid, pts in dominant_spine_points.items():
            st_geom = street_geoms[sid]; pts.sort(key=lambda x: x['station'])
            if len(pts) > 1:
                for i in range(len(pts) - 1):
                    p1 = pts[i]; p2 = pts[i+1]; start_pt = p1['pt']; end_pt = p2['pt']
                    cb = st_geom.interpolate(p1['station']).asPoint()
                    vx, vy = start_pt.x() - cb.x(), start_pt.y() - cb.y()
                    ct = st_geom.interpolate(p2['station']).asPoint()
                    off_pt = QgsPointXY(ct.x() + vx, ct.y() + vy)
                    seg = self.extract_curve_between(st_geom, p1['station'], p2['station'], start_pt, off_pt)
                    if seg: network_lines.append(seg); main_line_geoms[sid].append(seg)
                    if off_pt.sqrDist(end_pt) > 0.1:
                        straight_seg = QgsGeometry.fromPolylineXY([off_pt, end_pt]); network_lines.append(straight_seg); main_line_geoms[sid].append(straight_seg)
        for sid, tobys in crossing_tobys.items():
            st_geom = street_geoms[sid]; dom_pts = dominant_spine_points.get(sid, [])
            dom_idx = QgsSpatialIndex(); dom_map = {}
            for i, dp in enumerate(dom_pts):
                if dp['type'] == 'toby': f = QgsFeature(i); f.setGeometry(QgsGeometry.fromPointXY(dp['pt'])); dom_idx.addFeature(f); dom_map[i] = dp['pt']
            combined_main_line = None; parts = main_line_geoms[sid]
            if parts: combined_main_line = QgsGeometry.unaryUnion(parts)
            elif dom_pts:
                pt = dom_pts[0]['pt']; stat = dom_pts[0]['station']; p_next = st_geom.interpolate(stat + 10.0).asPoint()
                p_curr = st_geom.interpolate(stat).asPoint(); vx, vy = pt.x() - p_curr.x(), pt.y() - p_curr.y()
                virtual_next = QgsPointXY(p_next.x() + vx, p_next.y() + vy); combined_main_line = QgsGeometry.fromPolylineXY([pt, virtual_next])
            for t in tobys:
                toby_pt = t['location']; center_pt = st_geom.nearestPoint(QgsGeometry.fromPointXY(toby_pt)).asPoint()
                nearest_ids = dom_idx.nearestNeighbor(QgsGeometry.fromPointXY(center_pt), 1); toby_target = None
                if nearest_ids:
                    cand_pt = dom_map[nearest_ids[0]]; vx = center_pt.x() - toby_pt.x(); vy = center_pt.y() - toby_pt.y()
                    ray_end = QgsPointXY(center_pt.x() + vx*3, center_pt.y() + vy*3)
                    if QgsGeometry.fromPolylineXY([toby_pt, ray_end]).distance(QgsGeometry.fromPointXY(cand_pt)) < 2.0: toby_target = cand_pt
                if toby_target: network_lines.append(QgsGeometry.fromPolylineXY([toby_pt, toby_target]))
                elif combined_main_line:
                    proj_res = combined_main_line.nearestPoint(QgsGeometry.fromPointXY(toby_pt))
                    if not proj_res.isEmpty(): ix_pt = proj_res.asPoint(); network_lines.append(QgsGeometry.fromPolylineXY([toby_pt, ix_pt]))
        fdh_geo = QgsGeometry.fromPointXY(fdh_pt); fdh_sid = None; min_dist = float('inf')
        for sid in active_streets:
            d = street_geoms[sid].distance(fdh_geo)
            if d < min_dist: min_dist = d; fdh_sid = sid
        connected_streets = {fdh_sid} if fdh_sid else set(); unconnected_streets = set(dominant_spine_points.keys()) - connected_streets
        while unconnected_streets:
            best_link = None; min_link_dist = float('inf')
            for c_sid in connected_streets:
                geom_c = street_geoms[c_sid]
                for u_sid in unconnected_streets:
                    geom_u = street_geoms[u_sid]; ix_geom = geom_c.intersection(geom_u)
                    if not ix_geom.isEmpty():
                        if ix_geom.type() == QgsWkbTypes.PointGeometry: ix_pt = ix_geom.asPoint()
                        else: ix_pt = ix_geom.asMultiPoint()[0]
                        best_link = (c_sid, u_sid, ix_pt); min_link_dist = 0; break
                    res = geom_c.nearestPoint(geom_u)
                    if not res.isEmpty() and res.distance(geom_u) < 5.0: best_link = (c_sid, u_sid, res.asPoint()); min_link_dist = 0; break
                if min_link_dist == 0: break
            if best_link:
                c_sid, u_sid, ix_pt = best_link; c_pts = dominant_spine_points[c_sid]
                if c_pts:
                    c_end = min(c_pts, key=lambda p: QgsGeometry.fromPointXY(p['pt']).distance(QgsGeometry.fromPointXY(ix_pt)))
                    st_geom = street_geoms[c_sid]; stat_start = c_end['station']; stat_end = st_geom.lineLocatePoint(QgsGeometry.fromPointXY(ix_pt))
                    p_curr = st_geom.interpolate(stat_start).asPoint(); vx = c_end['pt'].x() - p_curr.x(); vy = c_end['pt'].y() - p_curr.y()
                    c_ix_off = QgsPointXY(ix_pt.x() + vx, ix_pt.y() + vy)
                    seg = self.extract_curve_between(st_geom, stat_start, stat_end, c_end['pt'], c_ix_off)
                    if seg: network_lines.append(seg)
                    u_pts = dominant_spine_points[u_sid]
                    if u_pts:
                        u_end = min(u_pts, key=lambda p: QgsGeometry.fromPointXY(p['pt']).distance(QgsGeometry.fromPointXY(ix_pt)))
                        st_geom_u = street_geoms[u_sid]; stat_start_u = u_end['station']; stat_end_u = st_geom_u.lineLocatePoint(QgsGeometry.fromPointXY(ix_pt))
                        p_curr_u = st_geom_u.interpolate(stat_start_u).asPoint(); vx_u = u_end['pt'].x() - p_curr_u.x(); vy_u = u_end['pt'].y() - p_curr_u.y()
                        u_ix_off = QgsPointXY(ix_pt.x() + vx_u, ix_pt.y() + vy_u)
                        network_lines.append(QgsGeometry.fromPolylineXY([c_ix_off, u_ix_off]))
                        seg_u = self.extract_curve_between(st_geom_u, stat_start_u, stat_end_u, u_end['pt'], u_ix_off)
                        if seg_u: network_lines.append(seg_u)
                connected_streets.add(u_sid); unconnected_streets.remove(u_sid)
            else: break
        self.msg("   Connecting FDH (Elbow Logic)..."); all_lines = []
        for g in network_lines:
             if g.isMultipart(): all_lines.extend(g.asMultiPolyline())
             else: all_lines.append(g.asPolyline())
        net_geom = QgsGeometry.fromMultiPolylineXY(all_lines)
        if not net_geom.isEmpty():
            nearest_res = net_geom.nearestPoint(fdh_geo)
            if not nearest_res.isEmpty():
                target_pt = nearest_res.asPoint()
                if fdh_sid:
                    st_geom = street_geoms[fdh_sid]; target_stat = st_geom.lineLocatePoint(QgsGeometry.fromPointXY(target_pt))
                    target_center = st_geom.interpolate(target_stat).asPoint(); off_vx = target_pt.x() - target_center.x(); off_vy = target_pt.y() - target_center.y()
                    fdh_stat = st_geom.lineLocatePoint(fdh_geo); fdh_center = st_geom.interpolate(fdh_stat).asPoint()
                    elbow_pt = QgsPointXY(fdh_center.x() + off_vx, fdh_center.y() + off_vy)
                    network_lines.append(QgsGeometry.fromPolylineXY([fdh_pt, elbow_pt]))
                    conn_seg = self.extract_curve_between(st_geom, fdh_stat, target_stat, elbow_pt, target_pt)
                    if conn_seg: network_lines.append(conn_seg)
                    else: network_lines.append(QgsGeometry.fromPolylineXY([elbow_pt, target_pt]))
                else: network_lines.append(QgsGeometry.fromPolylineXY([fdh_pt, target_pt]))
        full_net_union = QgsGeometry.fromMultiPolylineXY(all_lines); endpoints = []
        for line in all_lines:
            if len(line) < 2: continue
            endpoints.extend([line[0], line[-1]])
        for pt in endpoints:
            pt_geom = QgsGeometry.fromPointXY(pt); near_res = full_net_union.nearestPoint(pt_geom)
            if not near_res.isEmpty():
                d = near_res.distance(pt_geom)
                if 0.01 < d < 1.5: network_lines.append(QgsGeometry.fromPolylineXY([pt, near_res.asPoint()]))
        dist_data = []; fid = 1; unit_factor = 1.0
        if calc_crs.mapUnits() != QgsUnitTypes.DistanceFeet: unit_factor = 1/0.3048
        
        # --- GRAPH FLOW ORIENTATION ---
        final_geom_list = self.orient_network_flow(network_lines, fdh_pt)
        
        for g_final in final_geom_list:
            l = g_final.length() * unit_factor
            if not g_final.isMultipart(): g_final = QgsGeometry.fromMultiPolylineXY([g_final.asPolyline()])
            dist_data.append({'id': fid, 'geom': g_final, 'length_ft': round(l, 2)}); fid += 1
        
        project_crs = QgsProject.instance().crs()
        if self.rb_append.isChecked() and self.target_dist.currentLayer():
            target_lyr = self.target_dist.currentLayer()
            xform = QgsCoordinateTransform(calc_crs, target_lyr.crs(), QgsProject.instance())
            for d in dist_data: d['geom'].transform(xform)
            self.append_to_layer(target_lyr, dist_data, 'distribution')
        else: self.create_distribution_layer(dist_data, calc_crs, project_crs, self.area_select.currentText())
        self.add_fdh_marker(fdh_pt, calc_crs); self.msg(f"Step 3 Complete! {len(dist_data)} segments.")

    def run_step_5_conduits(self):
        self.msg("\nStep 4: CONDUIT SIZING"); dist_layer = self.conduit_dist_combo.currentLayer() or self._find_layer_by_type('distribution')
        toby_layer = self.conduit_toby_combo.currentLayer() or self._find_layer_by_type('toby')
        house_drops = self.conduit_drops_combo.currentLayer() or self._find_layer_by_type('drop'); fdh_layer = self.fdh_combo.currentLayer()
        boundary = self.get_boundary(); drop_bound_layer = self.drop_bound_combo.currentLayer()
        if not all([dist_layer, toby_layer, fdh_layer]): return self.msg("ERROR: Missing Layers!")
        if not boundary: boundary = toby_layer.extent()
        crs = dist_layer.crs().authid(); snap_tol = self.conduit_snap.value(); fdh_geom = None
        for f in fdh_layer.getFeatures():
            if boundary.contains(f.geometry()): fdh_geom = f.geometry(); break
        if not fdh_geom: return self.msg("ERROR: No FDH found inside boundary")
        dist_mem = QgsVectorLayer(f"MultiLineString?crs={crs}", "DistNet", "memory"); dp = dist_mem.dataProvider()
        dp.addAttributes([QgsField('orig_fid', QVariant.Int)]); dist_mem.updateFields()
        for f in dist_layer.getFeatures():
            if f.geometry().intersects(boundary): 
                g = f.geometry()
                if not g.isMultipart(): g = QgsGeometry.fromMultiPolylineXY([g.asPolyline()])
                nf = QgsFeature(); nf.setGeometry(g); nf.setAttributes([f.id()]); dp.addFeature(nf)
        drop_filter_geom = None
        if drop_bound_layer:
             sel = drop_bound_layer.selectedFeatures()
             if sel: drop_filter_geom = QgsGeometry.unaryUnion([f.geometry() for f in sel])
             else:
                 geoms = [f.geometry() for f in drop_bound_layer.getFeatures() if f.geometry().intersects(boundary)]
                 if geoms: drop_filter_geom = QgsGeometry.unaryUnion(geoms)
        points_data = []
        for f in toby_layer.getFeatures():
            g = f.geometry()
            if not g or not boundary.contains(g): continue
            if drop_filter_geom and not drop_filter_geom.contains(g): continue
            hc = 1
            for fn in ['house_count', 'fid_count', 'addresses']:
                idx = f.fields().indexOf(fn)
                if idx != -1 and f.attributes()[idx]:
                    val = f.attributes()[idx]
                    if fn == 'addresses' and isinstance(val, str): hc = len(val.split(','))
                    elif str(val).isdigit(): hc = int(val)
                    break
            if hc == 1 and house_drops: buf = g.buffer(5, 5); hc = sum(1 for d in house_drops.getFeatures() if d.geometry().intersects(buf)) or 1
            points_data.append({'geometry': g, 'house_count': hc})
        point_mem = QgsVectorLayer(f"Point?crs={crs}", "Points", "memory"); pp = point_mem.dataProvider()
        pp.addAttributes([QgsField('house_count', QVariant.Int)]); point_mem.updateFields()
        for pd in points_data: nf = QgsFeature(); nf.setGeometry(pd['geometry']); nf.setAttributes([pd['house_count']]); pp.addFeature(nf)
        snapped_pts = processing.run('native:snapgeometries', {'INPUT': point_mem, 'REFERENCE_LAYER': dist_mem, 'TOLERANCE': 25, 'BEHAVIOR': 0, 'OUTPUT': 'memory:'})['OUTPUT']
        snapped_net = processing.run('native:snapgeometries', {'INPUT': dist_mem, 'REFERENCE_LAYER': dist_mem, 'TOLERANCE': snap_tol, 'BEHAVIOR': 0, 'OUTPUT': 'memory:'})['OUTPUT']
        snapped_to_pts = processing.run('native:snapgeometries', {'INPUT': snapped_net, 'REFERENCE_LAYER': snapped_pts, 'TOLERANCE': snap_tol, 'BEHAVIOR': 0, 'OUTPUT': 'memory:'})['OUTPUT']
        split_at_pts = self.split_lines_at_points_v5(snapped_to_pts, snapped_pts, snap_tol)
        fdh_mem = QgsVectorLayer(f"Point?crs={crs}", "FDH", "memory"); ff = QgsFeature(); ff.setGeometry(fdh_geom); fdh_mem.dataProvider().addFeatures([ff])
        split_at_fdh = self.split_lines_at_points_v5(split_at_pts, fdh_mem, snap_tol)
        clean_net = processing.run('native:deleteduplicategeometries', {'INPUT': split_at_fdh, 'OUTPUT': 'memory:'})['OUTPUT']
        clean_topo = processing.run('native:removeduplicatevertices', {'INPUT': clean_net, 'TOLERANCE': 0.01, 'OUTPUT': 'memory:'})['OUTPUT']
        point_buffer = processing.run('native:buffer', {'INPUT': snapped_pts, 'DISTANCE': 1.5, 'SEGMENTS': 5, 'OUTPUT': 'memory:'})['OUTPUT']
        endpoint_idx = {}; line_features = {}
        for f in clean_topo.getFeatures():
            g = f.geometry(); line_features[f.id()] = f; polys = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for poly in polys:
                if len(poly) < 2: continue
                for pt in [poly[0], poly[-1]]:
                    key = (round(pt.x(), 2), round(pt.y(), 2))
                    if key not in endpoint_idx: endpoint_idx[key] = []
                    if f.id() not in endpoint_idx[key]: endpoint_idx[key].append(f.id())
        visited_lines = set(); visited_pts = set(); line_house_count = {}; line_children = {}; line_total = {}
        fdh_lines = [f.id() for f in clean_topo.getFeatures() if f.geometry().distance(fdh_geom) < snap_tol]
        for l in fdh_lines: visited_lines.add(l)
        def build_tree(fid):
            feat = clean_topo.getFeature(fid); line_house_count[fid] = 0
            for pt_f in point_buffer.getFeatures():
                if pt_f.id() not in visited_pts and pt_f.geometry().intersects(feat.geometry()):
                    visited_pts.add(pt_f.id()); line_house_count[fid] += pt_f['house_count']
            conn = []; g = feat.geometry(); polys = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for poly in polys:
                for pt in [poly[0], poly[-1]]:
                    key = (round(pt.x(), 2), round(pt.y(), 2))
                    if key in endpoint_idx:
                        for cid in endpoint_idx[key]:
                            if cid != fid and cid not in visited_lines: conn.append(cid)
            conn = list(set(conn)); line_children[fid] = []
            for c in conn: visited_lines.add(c); line_children[fid].append(c)
            for c in conn: build_tree(c)
        for fid in fdh_lines: build_tree(fid)
        def calc_total(fid):
            total = line_house_count.get(fid, 0)
            for c in line_children.get(fid, []): total += calc_total(c)
            line_total[fid] = total; return total
        for fid in fdh_lines: calc_total(fid)
        dist_out = QgsVectorLayer(f'MultiLineString?crs={crs}', 'Distribution_Conduit', 'memory'); dist_out.dataProvider().addAttributes([QgsField('TYPE', QVariant.String), QgsField('LENGTH', QVariant.Double), QgsField('house_count', QVariant.Int)]); dist_out.updateFields()
        drop_out = QgsVectorLayer(f'MultiLineString?crs={crs}', 'Drop_Conduit', 'memory'); drop_out.dataProvider().addAttributes([QgsField('TYPE', QVariant.String), QgsField('LENGTH', QVariant.Double), QgsField('house_count', QVariant.Int)]); drop_out.updateFields()
        for lid, hc in line_total.items():
            if hc == 0: continue
            feat = line_features.get(lid); geom = feat.geometry(); length = round(geom.length(), 2)
            
            # --- APPLY FLOW DIRECTION FIX TO CONDUITS ---
            geom = self.enforce_flow_direction(geom, fdh_geom.asPoint())
            if not geom.isMultipart(): geom = QgsGeometry.fromMultiPolylineXY([geom.asPolyline()])
            nf = QgsFeature(); nf.setGeometry(geom); ctype = 'CONDUIT-MD-1W'
            if hc > 10: ctype = 'CONDUIT-MD-24W'
            elif hc >= 3: ctype = 'CONDUIT-MD-12W'
            elif hc == 2: ctype = 'CONDUIT-MD-2W'
            nf.setAttributes([ctype, length, hc])
            if hc > 2: dist_out.dataProvider().addFeature(nf)
            else: drop_out.dataProvider().addFeature(nf)
        if self.rb_append.isChecked():
            if self.target_conduit_dist.currentLayer(): self.append_to_layer(self.target_conduit_dist.currentLayer(), [{'geom': f.geometry(), 'TYPE': f['TYPE'], 'LENGTH': f['LENGTH'], 'house_count': f['house_count']} for f in dist_out.getFeatures()], 'conduit')
            if self.target_conduit_drop.currentLayer(): self.append_to_layer(self.target_conduit_drop.currentLayer(), [{'geom': f.geometry(), 'TYPE': f['TYPE'], 'LENGTH': f['LENGTH'], 'house_count': f['house_count']} for f in drop_out.getFeatures()], 'conduit')
        else:
            self._apply_conduit_styling(dist_out); self._apply_conduit_styling(drop_out)
            QgsProject.instance().addMapLayer(dist_out); QgsProject.instance().addMapLayer(drop_out)
        self.msg(f"Step 4 Complete! Processed {len(line_total)} segments.")

    def split_lines_at_points_v5(self, line_layer, point_layer, tolerance):
        split_points = [QgsPointXY(f.geometry().asPoint()) for f in point_layer.getFeatures()]
        crs_id = line_layer.crs().authid()
        output = QgsVectorLayer(f"MultiLineString?crs={crs_id}", "Split_Lines", "memory")
        output.dataProvider().addAttributes(line_layer.fields())
        output.updateFields()
        new_features = []
        for line_feat in line_layer.getFeatures():
            line_geom = line_feat.geometry()
            if not line_geom or line_geom.isEmpty(): continue
            polys = line_geom.asMultiPolyline() if line_geom.isMultipart() else [line_geom.asPolyline()]
            for polyline in polys:
                if len(polyline) < 2: continue
                line_g = QgsGeometry.fromPolylineXY(polyline)
                line_length = line_g.length()
                split_positions = []
                for sp in split_points:
                    pt_geom = QgsGeometry.fromPointXY(sp)
                    if line_g.distance(pt_geom) <= tolerance:
                        pos = line_g.lineLocatePoint(line_g.nearestPoint(pt_geom))
                        if pos > tolerance and pos < (line_length - tolerance): split_positions.append(pos)
                split_positions = sorted(set(split_positions))
                if not split_positions:
                    nf = QgsFeature(line_feat); nf.setGeometry(QgsGeometry.fromMultiPolylineXY([polyline])); new_features.append(nf)
                else:
                    split_positions = [0] + split_positions + [line_length]
                    for i in range(len(split_positions)-1):
                        start, end = split_positions[i], split_positions[i+1]
                        if end - start < tolerance: continue
                        seg_pts = []
                        accum = 0
                        for j in range(len(polyline)-1):
                            p1, p2 = polyline[j], polyline[j+1]
                            seg_len = math.sqrt((p2.x()-p1.x())**2 + (p2.y()-p1.y())**2)
                            seg_s, seg_e = accum, accum + seg_len
                            if seg_e >= start and seg_s <= end:
                                if seg_s < start:
                                    t = (start - seg_s)/seg_len if seg_len>0 else 0
                                    seg_pts.append(QgsPointXY(p1.x()+t*(p2.x()-p1.x()), p1.y()+t*(p2.y()-p1.y())))
                                elif not seg_pts: seg_pts.append(p1)
                                if seg_s >= start and seg_e <= end:
                                    if seg_pts and seg_pts[-1]!=p1: seg_pts.append(p1)
                                    if p2!=p1: seg_pts.append(p2)
                                if seg_e > end:
                                    t = (end - seg_s)/seg_len if seg_len>0 else 0
                                    seg_pts.append(QgsPointXY(p1.x()+t*(p2.x()-p1.x()), p1.y()+t*(p2.y()-p1.y()))); break
                            accum = seg_e
                        if len(seg_pts) >= 2:
                            nf = QgsFeature(); nf.setGeometry(QgsGeometry.fromMultiPolylineXY([seg_pts]))
                            nf.setAttributes(line_feat.attributes()); new_features.append(nf)
        output.dataProvider().addFeatures(new_features); return output

    def create_layer_tobys(self, tobys, source_crs, target_crs):
        lyr = QgsVectorLayer(f"Point?crs={target_crs.authid()}", "Proposed_Tobys", "memory")
        lyr.dataProvider().addAttributes([QgsField("toby_id", QVariant.Int), QgsField("house_count", QVariant.Int), QgsField("street_name", QVariant.String), QgsField("addresses", QVariant.String), QgsField("road_side", QVariant.String), QgsField("fdh_area", QVariant.String)])
        lyr.updateFields()
        xform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
        area = self.area_select.currentText()
        for t in tobys:
            geom = QgsGeometry.fromPointXY(t['location'])
            geom.transform(xform)
            f = QgsFeature(); f.setGeometry(geom)
            f.setAttributes([t['id'], t['house_count'], t['street_name'], t['addresses_served'], t['road_side'], area])
            lyr.dataProvider().addFeature(f)
        lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({'name': 'circle', 'color': '#ff00ff', 'size': '4', 'outline_color': 'black'}))
        QgsProject.instance().addMapLayer(lyr)

    def create_layer_houses(self, houses, source_crs, target_crs):
        lyr = QgsVectorLayer(f"Point?crs={target_crs.authid()}", "Houses_Matched", "memory")
        lyr.dataProvider().addAttributes([QgsField("house_id", QVariant.String), QgsField("toby_id", QVariant.Int)])
        lyr.updateFields()
        xform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
        for h in houses:
            geom = QgsGeometry.fromPointXY(h['pt'])
            geom.transform(xform)
            f = QgsFeature(); f.setGeometry(geom)
            f.setAttributes([str(h['id']), h.get('toby_id', 0)])
            lyr.dataProvider().addFeature(f)
        QgsProject.instance().addMapLayer(lyr)

    def create_layer_drops(self, drops, source_crs, target_crs):
        lyr = QgsVectorLayer(f"MultiLineString?crs={target_crs.authid()}", "Drop_Cables", "memory")
        lyr.dataProvider().addAttributes([QgsField("from_toby_id", QVariant.Int), QgsField("to_address", QVariant.String), QgsField("street_name", QVariant.String), QgsField("length_ft", QVariant.Double)])
        lyr.updateFields()
        xform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
        for d in drops:
            geom = d['geom']; geom.transform(xform)
            if not geom.isMultipart(): geom = QgsGeometry.fromMultiPolylineXY([geom.asPolyline()])
            f = QgsFeature(); f.setGeometry(geom)
            l = d['geom'].length(); l = l/0.3048 if source_crs.mapUnits()!=QgsUnitTypes.DistanceFeet else l
            f.setAttributes([d['from_toby_id'], d['to_address'], d.get('street_name', ''), round(l, 2)])
            lyr.dataProvider().addFeature(f)
        lyr.renderer().setSymbol(QgsLineSymbol.createSimple({'color': 'red', 'width': '0.8'}))
        QgsProject.instance().addMapLayer(lyr); return lyr

    def create_distribution_layer(self, dist_data, source_crs, target_crs, fdh_area):
        lyr = QgsVectorLayer(f"MultiLineString?crs={target_crs.authid()}", "Distribution_Network", "memory")
        lyr.dataProvider().addAttributes([QgsField("id", QVariant.Int), QgsField("length_ft", QVariant.Double), QgsField("fdh_area", QVariant.String)])
        lyr.updateFields()
        xform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
        count = 0; safe_area = str(fdh_area) if fdh_area is not None else ""
        for d in dist_data:
            geom = d['geom']
            lines_to_add = []
            if geom.isMultipart(): lines_to_add = geom.asMultiPolyline()
            else: lines_to_add = [geom.asPolyline()]
            for l in lines_to_add:
                if len(l) < 2: continue
                poly_geom = QgsGeometry.fromPolylineXY(l)
                poly_geom.transform(xform)
                if not poly_geom.isMultipart(): poly_geom = QgsGeometry.fromMultiPolylineXY([poly_geom.asPolyline()])
                f = QgsFeature(); f.setGeometry(poly_geom)
                f.setAttributes([int(d['id']), float(d['length_ft']), safe_area])
                if lyr.dataProvider().addFeature(f): count += 1
        lyr.updateExtents(); lyr.triggerRepaint()
        if count > 0:
            symbol = QgsLineSymbol.createSimple({'color': '#ff00ff', 'width': '0.8'})
            lyr.renderer().setSymbol(symbol)
            QgsProject.instance().addMapLayer(lyr)
        return lyr

    def append_to_layer(self, target, data, type_):
        target.startEditing()
        req = {}
        if type_ == 'toby': req = {'toby_id': QVariant.Int, 'house_count': QVariant.Int, 'street_name': QVariant.String, 'addresses': QVariant.String, 'road_side': QVariant.String, 'fdh_area': QVariant.String}
        elif type_ == 'drop': req = {'from_toby_id': QVariant.Int, 'to_address': QVariant.String, 'street_name': QVariant.String, 'length_ft': QVariant.Double}
        elif type_ == 'distribution': req = {'id': QVariant.Int, 'length_ft': QVariant.Double, 'fdh_area': QVariant.String}
        elif type_ == 'conduit': req = {'TYPE': QVariant.String, 'LENGTH': QVariant.Double, 'house_count': QVariant.Int}
        curr = [f.name().lower() for f in target.fields()]
        for n, t in req.items(): 
            if n.lower() not in curr: target.dataProvider().addAttributes([QgsField(n, t)])
        target.updateFields()
        fm = {f.name().lower(): i for i, f in enumerate(target.fields())}
        area = self.area_select.currentText()
        for d in data:
            f = QgsFeature(target.fields())
            if type_ == 'toby':
                f.setGeometry(QgsGeometry.fromPointXY(d['location']))
                if 'toby_id' in fm: f[fm['toby_id']] = d['id']
                if 'house_count' in fm: f[fm['house_count']] = d.get('house_count', 0)
                if 'street_name' in fm: f[fm['street_name']] = d.get('street_name', '')
                if 'addresses' in fm: f[fm['addresses']] = d.get('addresses_served', '')
                if 'fdh_area' in fm: f[fm['fdh_area']] = area
            elif type_ == 'drop':
                g = d['geom']
                if not g.isMultipart(): g = QgsGeometry.fromMultiPolylineXY([g.asPolyline()])
                f.setGeometry(g)
                if 'from_toby_id' in fm: f[fm['from_toby_id']] = d.get('from_toby_id', 0)
                if 'to_address' in fm: f[fm['to_address']] = d.get('to_address', '')
                if 'length_ft' in fm: f[fm['length_ft']] = d.get('length_ft', 0)
            elif type_ == 'distribution':
                g = d['geom']
                if not g.isMultipart(): g = QgsGeometry.fromMultiPolylineXY([g.asPolyline()])
                f.setGeometry(g)
                if 'id' in fm: f[fm['id']] = d['id']
                if 'length_ft' in fm: f[fm['length_ft']] = d['length_ft']
                if 'fdh_area' in fm: f[fm['fdh_area']] = area
            elif type_ == 'conduit':
                g = d['geom']
                if not g.isMultipart(): g = QgsGeometry.fromMultiPolylineXY([g.asPolyline()])
                f.setGeometry(g)
                if 'type' in fm: f[fm['type']] = d.get('TYPE', '')
                if 'length' in fm: f[fm['length']] = d.get('LENGTH', 0)
                if 'house_count' in fm: f[fm['house_count']] = d.get('house_count', 0)
            target.dataProvider().addFeature(f)
        target.commitChanges(); target.triggerRepaint()

    def add_fdh_marker(self, fdh_pt_calc, source_crs):
        target_crs = QgsProject.instance().crs()
        xform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
        geom = QgsGeometry.fromPointXY(fdh_pt_calc)
        geom.transform(xform)
        lyr = QgsVectorLayer(f"Point?crs={target_crs.authid()}", "FDH_Location", "memory")
        f = QgsFeature(); f.setGeometry(geom); lyr.dataProvider().addFeatures([f])
        lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({'name': 'square', 'color': '#00ff00', 'size': '5', 'outline_color': 'black'}))
        QgsProject.instance().addMapLayer(lyr)

    def _find_layer_by_type(self, layer_type):
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.type() != QgsMapLayer.VectorLayer: continue
            nm = lyr.name().lower()
            if layer_type == 'toby' and lyr.geometryType() == QgsWkbTypes.PointGeometry and ('toby' in nm or 'proposed' in nm): return lyr
            if layer_type == 'drop' and lyr.geometryType() == QgsWkbTypes.LineGeometry and 'drop' in nm and 'conduit' not in nm: return lyr
            if layer_type == 'distribution' and lyr.geometryType() == QgsWkbTypes.LineGeometry and 'distribution' in nm and 'conduit' not in nm: return lyr
        return None

# ========================== PLUGIN ENTRY ==========================
class FTTHPlannerPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None

    def initGui(self):
        self.action = QAction(QIcon(""), "FTTH Planner Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&FTTH Tools", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&FTTH Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if not self.dlg:
            self.dlg = FTTHPlannerDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()