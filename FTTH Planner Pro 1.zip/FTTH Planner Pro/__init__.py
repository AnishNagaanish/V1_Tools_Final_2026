def classFactory(iface):
    from .main_plugin import FTTHPlannerPlugin
    return FTTHPlannerPlugin(iface)