import os
from qgis.PyQt.QtWidgets import (QAction, QDialog, QVBoxLayout, QLabel, QPushButton, 
                                 QScrollArea, QWidget, QGridLayout, QTabWidget, 
                                 QLineEdit, QFormLayout, QListWidget, QMessageBox, 
                                 QComboBox, QHBoxLayout, QFrame)
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtCore import Qt, QTimer, QVariant
from qgis.core import (QgsProject, QgsMapLayerType, QgsFeature, QgsGeometry, 
                       QgsWkbTypes, QgsProcessing, QgsField, QgsVectorLayer, 
                       QgsSpatialIndex, QgsPointXY)
from qgis.gui import QgsMapToolIdentifyFeature, QgsRubberBand
from qgis.utils import iface
import processing

# ==============================================================================
# MODERN STYLE SHEET (QSS)
# ==============================================================================
STYLE_SHEET = """
QDialog {
    background-color: #f5f5f5;
    color: #333333;
}
QTabWidget::pane {
    border: 1px solid #c4c4c4;
    background: white;
    border-radius: 5px;
}
QTabBar::tab {
    background: #e1e1e1;
    border: 1px solid #c4c4c4;
    padding: 8px 20px;
    margin-right: 2px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    color: #333;
}
QTabBar::tab:selected {
    background: white;
    border-bottom-color: white;
    font-weight: bold;
    color: #0078d7;
}
QPushButton {
    background-color: #0078d7;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 4px;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #005a9e;
}
QPushButton#cancel_btn {
    background-color: #d9534f;
}
QLineEdit, QComboBox, QListWidget {
    border: 1px solid #ccc;
    border-radius: 3px;
    padding: 4px;
    background: white;
    color: black;
    selection-background-color: #0078d7;
}
QComboBox QAbstractItemView {
    background-color: white;
    color: black;
    border: 1px solid #ccc;
    selection-background-color: #0078d7;
    selection-color: white;
}
QLabel {
    font-size: 11px;
    color: #555;
    font-weight: bold;
}
"""

# ==============================================================================
# LOGIC BLOCK 1: ELEMENT ID CLASSES
# ==============================================================================

class CustomIdentifyTool(QgsMapToolIdentifyFeature):
    def __init__(self, canvas, layer, dialog):
        super().__init__(canvas)
        self.canvas = canvas
        self.layer = layer
        self.dialog = dialog
        self.rubberBand = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
        self.rubberBand.setColor(QColor(255, 0, 0))
        self.rubberBand.setWidth(2)
 
    def canvasReleaseEvent(self, event):
        results = self.identify(event.x(), event.y(), [self.layer], self.TopDownStopAtFirst)
        if results:
            self.featureIdentified(results)
        else:
            self.rubberBand.reset(QgsWkbTypes.LineGeometry)
            self.dialog.selected_line_id = None
            self.dialog.line_id_label.setText("Selected Line ID: None")
 
    def featureIdentified(self, features):
        selected_line_id = []
        selected_features = []
        
        for result in features:
            feature = result.mFeature
            if feature.isValid():
                self.rubberBand.reset(QgsWkbTypes.LineGeometry)
                geom = feature.geometry()
                if geom:
                    self.rubberBand.setToGeometry(geom, self.layer)
                    self.rubberBand.show()
                
                if 'ACL_ID' in feature.fields().names():
                    selected_line_id.append(feature.attribute("ACL_ID"))
                
                selected_features.append(feature)
        
        self.dialog.selected_line_id = selected_line_id
        self.dialog.selected_features = selected_features
        self.dialog.line_id_label.setText(f"Selected Line ID: {selected_line_id}")
        self.dialog.create_feature_buttons(selected_features)
        self.canvas.refresh()
 
    def deactivate(self):
        self.cleanup()
        super().deactivate()
 
    def cleanup(self):
        self.rubberBand.reset(QgsWkbTypes.LineGeometry)
        self.canvas.refresh()

class LineSelectionDialog(QDialog):
    def __init__(self, ip, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Route Selection")
        self.rt = ip
        self.idx = 1
        self.selected_line_id = None
        self.last_updated_feature = None
        self.identify_tool = None
        self.result = None
        
        try:
            self.layer = QgsProject.instance().mapLayersByName('Hexatronics Distribution Conduit')[0]
            self.fdh = QgsProject.instance().mapLayersByName('Hexatronics Distribution Areas')[0]
        except IndexError:
             QMessageBox.critical(self, "Error", "Required Layers 'Hexatronics Distribution Conduit' or 'Areas' not found.")
             self.close()
             return

        self.selected_features = []
        self.visited_lines = set()
        self.setup_ui()
        self.rubber_band = None
 
    def setup_ui(self):
        self.update_crossing()
        layout = QVBoxLayout()
        self.line_id_label = QLabel("Selected Line ID: None")
        layout.addWidget(self.line_id_label)
        self.scroll_area = QScrollArea()
        self.scroll_content = QWidget()
        self.scroll_layout = QGridLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        self.scroll_area.setWidgetResizable(True)
        layout.addWidget(self.scroll_area)
        
        self.select_button = QPushButton("Enable Line Selection")
        self.select_button.clicked.connect(self.enable_selection)
        layout.addWidget(self.select_button)
        
        self.ok_button = QPushButton("OK (Process DFS)")
        self.ok_button.clicked.connect(self.accept_selection)
        layout.addWidget(self.ok_button)
        
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setObjectName("cancel_btn")
        self.cancel_button.clicked.connect(self.reject_selection)
        layout.addWidget(self.cancel_button)
        
        self.setLayout(layout)
        self.setMinimumWidth(400)
        self.setMinimumHeight(500)
        
    def update_crossing(self):
        field_name = "crossing"
        field_index = self.layer.fields().indexFromName(field_name)
        if field_index == -1:
            try:
                outputs={}
                highway_layer = QgsProject.instance().mapLayersByName('highway')[0]
                alg_params = {
                'CONVERT_CURVED_GEOMETRIES': False,
                'INPUT': highway_layer,
                'OPERATION': '',
                'TARGET_CRS': 'ProjectCrs',
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
                    }
                outputs['high'] = processing.run('native:reprojectlayer', alg_params)
                highway_layer = outputs['high']['OUTPUT']
                
                self.layer.startEditing()
                field = QgsField(field_name, QVariant.String)
                self.layer.addAttribute(field)
                self.layer.updateFields() 
                
                for feature in self.layer.getFeatures():
                    geom = feature.geometry()
                    feature[field_name] = 'f'
                    self.layer.updateFeature(feature)
                    for highway_feature in highway_layer.getFeatures():
                        if geom.intersects(highway_feature.geometry()):
                            feature[field_name] = 't'
                            self.layer.updateFeature(feature)
                            break
                self.layer.commitChanges()
            except Exception as e:
                print(f"Crossing update skipped or failed: {e}")
 
    def enable_selection(self):
        self.layer.startEditing()
        if self.layer and self.layer.type() == QgsMapLayerType.VectorLayer:
            self.identify_tool = CustomIdentifyTool(iface.mapCanvas(), self.layer, self)
            iface.mapCanvas().setMapTool(self.identify_tool)
 
    def create_feature_buttons(self, features):
        for i in reversed(range(self.scroll_layout.count())): 
            self.scroll_layout.itemAt(i).widget().setParent(None)
            
        self.scroll_area.show()
        for idx, feature in enumerate(features):
            if feature.id() not in self.visited_lines:
                button = QPushButton(f"Feature {idx + 1}")
                button.clicked.connect(lambda checked, f=feature: self.show_feature_details(f))
                
                if 'ACL_ID' in feature.fields().names():
                    acl_id = feature.attribute("ACL_ID")
                    button.setText(f"Feature {idx + 1} - ACL ID: {acl_id}")
                row = idx // 3
                col = idx % 3
                self.scroll_layout.addWidget(button, row, col)
            
    def flash_feature(self, feature):
        if hasattr(self, 'rubber_band') and self.rubber_band:
            self.rubber_band.reset(QgsWkbTypes.LineGeometry)
        
        self.rubber_band = QgsRubberBand(iface.mapCanvas(), QgsWkbTypes.LineGeometry)
        self.rubber_band.setColor(QColor(0, 0, 255))  
        self.rubber_band.setWidth(5)  
        
        geom = feature.geometry()
        if geom:
            self.rubber_band.setToGeometry(geom, self.layer)
        
        self.flash_count = 0
        self.flash_timer = QTimer()
        self.flash_timer.timeout.connect(self.toggle_flash)
        self.flash_timer.start(500)  
        
    def toggle_flash(self):
        if self.flash_count >= 6:  
            self.flash_timer.stop()
            if self.rubber_band:
                self.rubber_band.reset(QgsWkbTypes.LineGeometry)
            return
        if self.rubber_band:
            self.rubber_band.setVisible(not self.rubber_band.isVisible())
        self.flash_count += 1

    def show_feature_details(self, line):
        self.flash_feature(line)
        reply = QMessageBox.question(self, 'Confirmation', 
                                     "Do You Want Proceed With Conduit?", 
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            if line:
                element_id = f'RT{self.rt}-{str(self.idx).zfill(3)}'
                line['ELEMENTID'] = element_id
                self.layer.updateFeature(line)
                self.last_updated_feature = line
                self.visited_lines.add(line.id())
                self.idx += 1
                    
    def get_fdh(self, feature):
        output_layer = QgsVectorLayer(f'LineString?crs={self.layer.crs().authid()}', 'TempLayer', 'memory')
        new_feature = QgsFeature()
        new_feature.setGeometry(feature.geometry())
        output_layer.dataProvider().addFeature(new_feature)
        output_layer.updateExtents()
        
        alg_params = {
        'INPUT': self.fdh,
        'INTERSECT': output_layer,
        'PREDICATE': [0],  # intersect
        'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            }
        output = processing.run('native:extractbylocation', alg_params)
        
        temp_fdh = output['OUTPUT']
        if temp_fdh.featureCount() > 0:
            fdh_feature = next(temp_fdh.getFeatures())
            self.fdh_geom = fdh_feature.geometry()
        else:
             print("No intersecting FDH found")
             self.fdh_geom = QgsGeometry()

    def accept_selection(self):
        self.result = self.selected_line_id
        if self.last_updated_feature:
            self.get_fdh(self.last_updated_feature)
            self.perform_dfs(self.last_updated_feature)
        print(f'RT{self.rt} is updated successfully')
        self.layer.commitChanges()
        self.cleanup()
        self.close()

    def reject_selection(self):
        self.result = None
        self.layer.commitChanges()
        self.cleanup()
        self.close()

    def cleanup(self):
        if self.identify_tool:
            self.identify_tool.cleanup()
        iface.mapCanvas().unsetMapTool(self.identify_tool)
        iface.mapCanvas().refresh()
        
    def perform_dfs(self, start_feature):
        lines = self.get_intersecting_lines(start_feature)
        if lines == []:
            return
        for feature in lines:
            feature['ELEMENTID'] = f'RT{self.rt}-{str(self.idx).zfill(3)}'
            self.layer.updateFeature(feature)
            print(feature['ACL_ID'], feature['ELEMENTID'])
            self.idx+=1
            self.perform_dfs(feature)
            
    def get_intersecting_lines(self, bore_line):
        intersecting_lines = []
        parts = bore_line.geometry().asMultiPolyline()
        if not parts: return []
        end_point = parts[-1][-1]
        
        for bore in self.layer.getFeatures():
            if bore.id() == bore_line.id(): continue 
            
            b_parts = bore.geometry().asMultiPolyline()
            if not b_parts: continue
            start_point = b_parts[0][0]
            
            if end_point.distance(start_point) < 1 and (bore.id() not in self.visited_lines):
                 if hasattr(self, 'fdh_geom') and bore_line.geometry().within(self.fdh_geom):
                    if bore['crossing']=='t':
                        intersecting_lines = [bore]+intersecting_lines
                    else:
                        intersecting_lines.append(bore)
                    self.visited_lines.add(bore.id())
        return intersecting_lines


# ==============================================================================
# MAIN PLUGIN UI CLASS
# ==============================================================================

class FTTHPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dlg = None

    def initGui(self):
        self.action = QAction(QIcon(""), "FTTH Automation Suite", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&FTTH Tools", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&FTTH Tools", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if not self.dlg:
            self.dlg = MainPluginDialog(self.iface)
        self.dlg.show()
        self.dlg.exec_()


class MainPluginDialog(QDialog):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.setWindowTitle("FTTH Automation Suite")
        self.resize(600, 500)
        self.setStyleSheet(STYLE_SHEET)
        
        self.layout = QVBoxLayout()
        self.tabs = QTabWidget()
        self.layout.addWidget(self.tabs)
        self.setLayout(self.layout)
        
        # --- TAB 1 ---
        self.tab1 = QWidget()
        self.setup_tab1()
        self.tabs.addTab(self.tab1, "1. Route / ID Generator")
        
        # --- TAB 2 ---
        self.tab2 = QWidget()
        self.setup_tab2()
        self.tabs.addTab(self.tab2, "2. DAP/Toby Naming")
        
        # --- TAB 3 ---
        self.tab3 = QWidget()
        self.setup_tab3()
        self.tabs.addTab(self.tab3, "3. From-To Connectivity")

    # ========================== TAB 1 SETUP ==========================
    def setup_tab1(self):
        layout = QVBoxLayout()
        info = QLabel("Generates ElementIDs using DFS algorithm within FDH boundaries.\nRequires 'Hexatronics Distribution Conduit' layer.")
        layout.addWidget(info)
        form = QFormLayout()
        self.t1_route_input = QLineEdit()
        self.t1_route_input.setPlaceholderText("Enter Integer (e.g. 101)")
        form.addRow("Enter Route Number:", self.t1_route_input)
        layout.addLayout(form)
        btn = QPushButton("Launch Selection Tool")
        btn.clicked.connect(self.run_element_id_logic)
        layout.addWidget(btn)
        layout.addStretch()
        self.tab1.setLayout(layout)

    def run_element_id_logic(self):
        try:
            val = int(self.t1_route_input.text())
        except ValueError:
            QMessageBox.warning(self, "Input Error", "Please enter a valid integer for Route Number.")
            return
        dialog = LineSelectionDialog(val, self)
        dialog.show()
        dialog.exec_()

    # ========================== TAB 2 SETUP ==========================
    def setup_tab2(self):
        layout = QVBoxLayout()
        form = QFormLayout()
        
        # 1. Polygon Layer
        self.t2_poly_layer = QComboBox()
        self.populate_layers(self.t2_poly_layer, QgsWkbTypes.PolygonGeometry)
        self.t2_poly_layer.currentIndexChanged.connect(lambda: self.update_fields(self.t2_poly_layer, self.t2_filter_attr))
        
        # 2. Filter Attribute (Column)
        self.t2_filter_attr = QComboBox()
        self.t2_filter_attr.currentIndexChanged.connect(lambda: self.update_values(self.t2_poly_layer, self.t2_filter_attr, self.t2_filter_val))
        
        # 3. Filter Value (Content of Column)
        self.t2_filter_val = QComboBox()
        self.t2_filter_val.setEditable(True) # Allow typing if value missing
        
        # 4. Point Layer
        self.t2_point_layer = QComboBox()
        self.populate_layers(self.t2_point_layer, QgsWkbTypes.PointGeometry)
        
        # 5. Middle String
        self.t2_mid_str = QLineEdit()
        self.t2_mid_str.setPlaceholderText("'DAP' or 'HH'")
        
        form.addRow("Polygon Layer (Areas):", self.t2_poly_layer)
        form.addRow("Filter Column (e.g. LABEL):", self.t2_filter_attr)
        form.addRow("Select FDH Value:", self.t2_filter_val)
        form.addRow("Target Point Layer:", self.t2_point_layer)
        form.addRow("Middle String:", self.t2_mid_str)
        
        layout.addLayout(form)
        
        btn = QPushButton("Sequence Points")
        btn.clicked.connect(self.run_dap_logic)
        layout.addWidget(btn)
        layout.addStretch()
        self.tab2.setLayout(layout)

    def run_dap_logic(self):
        try:
            poly_name = self.t2_poly_layer.currentText()
            filter_col = self.t2_filter_attr.currentText()
            filter_val = self.t2_filter_val.currentText()
            point_layer_name = self.t2_point_layer.currentText()
            mid_str = self.t2_mid_str.text()
            
            start_ref_layer = QgsProject.instance().mapLayersByName('FDH')[0]
            point_layer = QgsProject.instance().mapLayersByName(point_layer_name)[0]
            poly_layer = QgsProject.instance().mapLayersByName(poly_name)[0]
            
            self.sequence_points_within_polygon(point_layer, poly_layer, start_ref_layer, 
                                              filter_col, filter_val, 'ELEMENTID', mid_str)
            QMessageBox.information(self, "Success", "Sequencing Complete.")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def sequence_points_within_polygon(self, point_layer, polygon_layer, point_1_layer, 
                                     filter_attr, filter_val, concat_attr, mid_str):
        if point_layer.fields().indexOf("ELEMENTID") == -1:
            point_layer.startEditing()
            point_layer.dataProvider().addAttributes([QgsField("ELEMENTID", QVariant.String)])
            point_layer.updateFields()
        
        point_layer.startEditing()
        
        # Filter using selected Column and Value
        selected_polygons = [poly for poly in polygon_layer.getFeatures() if str(poly[filter_attr]) == str(filter_val)]
        
        if not selected_polygons:
            print("No polygons found matching criteria.")
            return

        for polygon in selected_polygons:
            nearest_distance = float('inf')
            start_point_feature = None
            
            for point_1_feature in point_1_layer.getFeatures():
                point_1_geom = point_1_feature.geometry()
                for point_feature in point_layer.getFeatures():
                    if polygon.geometry().contains(point_feature.geometry()):
                        distance = point_feature.geometry().distance(point_1_geom)
                        if distance < nearest_distance:
                            nearest_distance = distance
                            start_point_feature = point_feature
            
            if start_point_feature is None:
                continue

            branch_features = [start_point_feature]
            remaining_features = [
                f for f in point_layer.getFeatures()
                if polygon.geometry().contains(f.geometry()) and f.id() != start_point_feature.id()
            ]

            current_feature = start_point_feature
            while remaining_features:
                next_feature = min(remaining_features, key=lambda f: current_feature.geometry().distance(f.geometry()))
                branch_features.append(next_feature)
                remaining_features.remove(next_feature)
                current_feature = next_feature

            sequence_number = 1
            for feature in branch_features:
                # Use the filter attribute value for naming
                concat_val = polygon[filter_attr]
                feature["ELEMENTID"] = f"{concat_val}-{mid_str}-{sequence_number:02}"
                point_layer.updateFeature(feature)
                sequence_number += 1
        
        point_layer.commitChanges()

    # ========================== TAB 3 SETUP ==========================
    def setup_tab3(self):
        layout = QVBoxLayout()
        form = QFormLayout()
        
        # 1. Boundary Polygon
        self.t3_poly_layer = QComboBox()
        self.populate_layers(self.t3_poly_layer, QgsWkbTypes.PolygonGeometry)
        self.t3_poly_layer.currentIndexChanged.connect(lambda: self.update_fields(self.t3_poly_layer, self.t3_filter_attr))
        
        # 2. Filter Attribute (Column)
        self.t3_filter_attr = QComboBox()
        self.t3_filter_attr.currentIndexChanged.connect(lambda: self.update_values(self.t3_poly_layer, self.t3_filter_attr, self.t3_filter_val))
        
        # 3. Filter Value (Content)
        self.t3_filter_val = QComboBox()
        self.t3_filter_val.setEditable(True)
        
        # 4. Line Layer
        self.t3_line_layer = QComboBox()
        self.populate_layers(self.t3_line_layer, QgsWkbTypes.LineGeometry)
        
        layout.addLayout(form)
        form.addRow("Boundary Polygon:", self.t3_poly_layer)
        form.addRow("Filter Column (e.g. LABEL):", self.t3_filter_attr)
        form.addRow("Select FDH Value:", self.t3_filter_val)
        form.addRow("Lines to Update:", self.t3_line_layer)
        
        layout.addWidget(QLabel("Select Point Layers (Multiselect):"))
        self.t3_point_list = QListWidget()
        self.t3_point_list.setSelectionMode(QListWidget.MultiSelection)
        self.populate_list_widget(self.t3_point_list, QgsWkbTypes.PointGeometry)
        layout.addWidget(self.t3_point_list)
        
        btn = QPushButton("Update From/To Attributes")
        btn.clicked.connect(self.run_from_to_logic)
        layout.addWidget(btn)
        self.tab3.setLayout(layout)

    def run_from_to_logic(self):
        try:
            poly_name = self.t3_poly_layer.currentText()
            line_name = self.t3_line_layer.currentText()
            filter_col = self.t3_filter_attr.currentText()
            filter_val = self.t3_filter_val.currentText()
            
            selected_items = self.t3_point_list.selectedItems()
            point_layer_names = [i.text() for i in selected_items]
            
            if not point_layer_names:
                raise Exception("No point layers selected.")

            poly_layer = QgsProject.instance().mapLayersByName(poly_name)[0]
            active_layer = QgsProject.instance().mapLayersByName(line_name)[0]
            point_layers = [QgsProject.instance().mapLayersByName(name)[0] for name in point_layer_names]

            # Dynamic Filter
            selected_polygons = [poly for poly in poly_layer.getFeatures() if str(poly[filter_col]) == str(filter_val)]
            if not selected_polygons:
                raise Exception(f"No polygons found where {filter_col} == {filter_val}")

            indices = {name: QgsSpatialIndex(layer.getFeatures()) for name, layer in zip(point_layer_names, point_layers)}
            
            active_layer.startEditing()
            line_features = list(active_layer.getFeatures())
            point_features = {name: {feat.id(): feat for feat in layer.getFeatures()} for name, layer in zip(point_layer_names, point_layers)}

            for line_feature in line_features:
                line_geometry = line_feature.geometry()
                
                if not any(poly.geometry().intersects(line_geometry) for poly in selected_polygons):
                    continue

                if line_geometry.isMultipart():
                    parts = line_geometry.asMultiPolyline()
                else:
                    parts = [line_geometry.asPolyline()]

                start_attribute = ''
                end_attribute = ''
                
                for part in parts:
                    if not part: continue
                    start_point = part[0]
                    end_point = part[-1]
                    start_geom = QgsGeometry.fromPointXY(QgsPointXY(start_point))
                    end_geom = QgsGeometry.fromPointXY(QgsPointXY(end_point))
                    
                    for name in point_layer_names:
                        nearest_start_id = indices[name].nearestNeighbor(start_geom.asPoint(), 1)
                        nearest_end_id = indices[name].nearestNeighbor(end_geom.asPoint(), 1)
                        
                        if nearest_start_id and not start_attribute:
                            start_feat = point_features[name][nearest_start_id[0]]
                            if start_feat.geometry().asPoint() == start_geom.asPoint():
                                start_attribute = start_feat['ELEMENTID']
                                
                        if nearest_end_id and not end_attribute:
                            end_feat = point_features[name][nearest_end_id[0]]
                            if end_feat.geometry().asPoint() == end_geom.asPoint():
                                end_attribute = end_feat['ELEMENTID']

                if start_attribute and end_attribute:
                    line_feature['from'] = start_attribute
                    line_feature['to'] = end_attribute
                    active_layer.updateFeature(line_feature)

            active_layer.commitChanges()
            QMessageBox.information(self, "Success", "From/To Update Completed.")

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ========================== HELPERS ==========================
    def populate_layers(self, combo, geom_type):
        combo.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.geometryType() == geom_type:
                combo.addItem(layer.name())

    def populate_list_widget(self, list_widget, geom_type):
        list_widget.clear()
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.geometryType() == geom_type:
                list_widget.addItem(layer.name())

    def update_fields(self, layer_combo, field_combo):
        """Populate field combo based on selected layer."""
        field_combo.clear()
        layer_name = layer_combo.currentText()
        if not layer_name: return
        
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if layers:
            layer = layers[0]
            fields = [field.name() for field in layer.fields()]
            field_combo.addItems(fields)
            
            # Auto-select LABEL or ELEMENTID if present
            if 'LABEL' in fields:
                field_combo.setCurrentIndex(fields.index('LABEL'))
            elif 'ELEMENTID' in fields:
                field_combo.setCurrentIndex(fields.index('ELEMENTID'))

    def update_values(self, layer_combo, field_combo, value_combo):
        """Populate value combo based on selected layer and field."""
        value_combo.clear()
        layer_name = layer_combo.currentText()
        field_name = field_combo.currentText()
        
        if not layer_name or not field_name: return
        
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if layers:
            layer = layers[0]
            idx = layer.fields().indexOf(field_name)
            if idx != -1:
                # Get unique values
                values = layer.uniqueValues(idx)
                str_values = sorted([str(v) for v in values if v is not None])
                value_combo.addItems(str_values)