def classFactory(iface):
    from .ftth_plugin_dialog import FTTHPlugin
    return FTTHPlugin(iface)