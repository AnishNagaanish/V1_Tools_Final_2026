def classFactory(iface):
    from .main_plugin import DapCreatorPlugin
    return DapCreatorPlugin(iface)