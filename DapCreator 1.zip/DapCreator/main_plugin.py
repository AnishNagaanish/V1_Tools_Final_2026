import os
from qgis.core import *
from qgis.gui import *
from qgis.PyQt.QtWidgets import *
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtCore import *
from collections import defaultdict

# ========================== POLYGON PICKER TOOL ==========================
class PolygonPickTool(QgsMapToolEmitPoint):
    def __init__(self, canvas, dialog):
        super().__init__(canvas)
        self.dialog = dialog
        
    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        self.dialog.handle_picked_polygon(point)
        self.dialog.iface.mapCanvas().unsetMapTool(self)
        self.dialog.show()

# ========================== MAIN DIALOG ==========================
class DapCreatorDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("DAP Creation Tool v1.3")
        self.resize(500, 650)
        self.pick_tool = None
        self.setup_ui()
        self.auto_select_layers()

    def setup_ui(self):
        # --- FIXED CSS FOR VISIBILITY ---
        self.setStyleSheet("""
            QDialog { background-color: #f0f2f5; font-family: 'Segoe UI'; font-size: 11px; }
            
            QGroupBox { 
                background-color: white; 
                border: 1px solid #b2bec3; 
                border-radius: 5px; 
                margin-top: 1em; 
                padding: 10px; 
                font-weight: bold; 
            }
            QGroupBox::title { 
                subcontrol-origin: margin; 
                top: 0; 
                padding: 0 3px; 
                color: #2d3436; 
            }
            
            QLabel { color: #636e72; font-weight: 500; }
            
            /* FORCE TEXT COLOR TO DARK GREY SO IT SHOWS ON WHITE BACKGROUND */
            QComboBox, QLineEdit, QSpinBox { 
                padding: 5px; 
                border: 1px solid #dfe6e9; 
                border-radius: 3px; 
                background: white; 
                color: #2d3436; 
            }
            
            /* STYLE THE DROPDOWN LIST ITEMS */
            QComboBox QAbstractItemView {
                background-color: #ffffff;
                color: #2d3436;
                selection-background-color: #3498db;
                selection-color: #ffffff;
            }
            
            QPushButton { 
                background-color: #0984e3; 
                color: white; 
                padding: 8px; 
                border-radius: 4px; 
                font-weight: bold; 
                border: none; 
            }
            QPushButton:hover { background-color: #74b9ff; }
            
            QCheckBox { color: #2d3436; }
        """)

        layout = QVBoxLayout(self)

        # --- 1. BOUNDARY INPUTS ---
        grp_bound = QGroupBox("1. Boundary Selection")
        l_bound = QFormLayout()
        
        self.combo_poly = QgsMapLayerComboBox()
        self.combo_poly.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.combo_poly.layerChanged.connect(self.on_poly_change)
        l_bound.addRow("Polygon Layer:", self.combo_poly)
        
        # Filter by Column & Value
        h_filter = QHBoxLayout()
        self.combo_field_fdh = QgsFieldComboBox()
        self.edit_fdh_val = QLineEdit()
        self.edit_fdh_val.setPlaceholderText("Enter Value (e.g. FDH-01)")
        h_filter.addWidget(self.combo_field_fdh, 1)
        h_filter.addWidget(self.edit_fdh_val, 1)
        l_bound.addRow("Filter ID:", h_filter)
        
        # Pick Button
        self.btn_pick = QPushButton("Pick Polygon from Map")
        self.btn_pick.setStyleSheet("background-color: #6c5ce7;")
        self.btn_pick.clicked.connect(self.activate_picker)
        l_bound.addRow("", self.btn_pick)
        
        grp_bound.setLayout(l_bound)
        layout.addWidget(grp_bound)

        # --- 2. NETWORK INPUTS ---
        grp_net = QGroupBox("2. Network Inputs")
        l_net = QFormLayout()
        
        self.combo_drop = QgsMapLayerComboBox()
        self.combo_drop.setFilters(QgsMapLayerProxyModel.LineLayer)
        l_net.addRow("Drop Cables:", self.combo_drop)
        
        self.combo_dist = QgsMapLayerComboBox()
        self.combo_dist.setFilters(QgsMapLayerProxyModel.LineLayer)
        l_net.addRow("Dist Conduit:", self.combo_dist)
        
        self.combo_dcond = QgsMapLayerComboBox()
        self.combo_dcond.setFilters(QgsMapLayerProxyModel.LineLayer)
        l_net.addRow("Drop Conduit:", self.combo_dcond)
        
        grp_net.setLayout(l_net)
        layout.addWidget(grp_net)

        # --- 3. OUTPUT SETTINGS ---
        grp_out = QGroupBox("3. Output")
        v_out = QVBoxLayout()
        self.chk_append = QCheckBox("Append to Existing Layer")
        self.chk_append.toggled.connect(self.toggle_append)
        v_out.addWidget(self.chk_append)
        
        self.combo_target = QgsMapLayerComboBox()
        self.combo_target.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.combo_target.setEnabled(False)
        v_out.addWidget(self.combo_target)
        grp_out.setLayout(v_out)
        layout.addWidget(grp_out)

        # --- LOG & RUN ---
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(100)
        self.log_box.setStyleSheet("background: #dfe6e9; border: 1px solid #b2bec3; color: #2d3436;")
        layout.addWidget(self.log_box)

        self.btn_run = QPushButton("Generate DAPs")
        self.btn_run.clicked.connect(self.run_logic)
        layout.addWidget(self.btn_run)
        
        self.on_poly_change()

    # --- UI EVENTS ---
    def on_poly_change(self):
        self.combo_field_fdh.setLayer(self.combo_poly.currentLayer())

    def toggle_append(self):
        self.combo_target.setEnabled(self.chk_append.isChecked())

    def msg(self, text):
        self.log_box.append(text)
        QApplication.processEvents()

    def activate_picker(self):
        if not self.combo_poly.currentLayer():
            return self.msg("Error: Select a Polygon layer first.")
        self.hide()
        self.pick_tool = PolygonPickTool(self.iface.mapCanvas(), self)
        self.iface.mapCanvas().setMapTool(self.pick_tool)
        self.iface.messageBar().pushMessage("Click on a polygon boundary...", level=Qgis.Info)

    def handle_picked_polygon(self, point):
        layer = self.combo_poly.currentLayer()
        rect = QgsGeometry.fromPointXY(point).buffer(1, 5).boundingBox()
        req = QgsFeatureRequest().setFilterRect(rect)
        
        found = False
        for f in layer.getFeatures(req):
            if f.geometry().contains(point):
                layer.selectByIds([f.id()]) # Select it
                self.msg(f"Polygon {f.id()} Selected.")
                found = True
                break
        if not found:
            self.msg("No polygon found at clicked location.")

    def auto_select_layers(self):
        poly_layer = QgsProject.instance().mapLayersByName("Hexatronics Distribution Areas")
        if poly_layer: self.combo_poly.setLayer(poly_layer[0])
        
        drop_c = QgsProject.instance().mapLayersByName("Drop_Cables")
        if drop_c: self.combo_drop.setLayer(drop_c[0])
        
        dist_c = QgsProject.instance().mapLayersByName("Distribution_Conduit")
        if dist_c: self.combo_dist.setLayer(dist_c[0])
        
        drop_cond = QgsProject.instance().mapLayersByName("Drop_Conduit")
        if drop_cond: self.combo_dcond.setLayer(drop_cond[0])

    # ==============================================================================
    # CORE LOGIC
    # ==============================================================================
    def run_logic(self):
        self.log_box.clear()
        self.msg("Starting DAP Creation...")
        
        poly_layer = self.combo_poly.currentLayer()
        drop_layer = self.combo_drop.currentLayer()
        dist_layer = self.combo_dist.currentLayer()
        dcond_layer = self.combo_dcond.currentLayer()
        
        fdh_field = self.combo_field_fdh.currentField()
        filter_val = self.edit_fdh_val.text().strip()
        
        if not (poly_layer and drop_layer and dist_layer and dcond_layer):
            self.msg("Error: Missing input layers.")
            return

        # 1. Determine Polygons to Process
        polygons = []
        
        # Priority 1: Picked/Selected on Map
        if poly_layer.selectedFeatureCount() > 0:
            polygons = list(poly_layer.selectedFeatures())
            self.msg(f"Using {len(polygons)} selected polygons.")
        
        # Priority 2: Filter Value (if text is entered)
        elif filter_val:
            expr = f"\"{fdh_field}\" = '{filter_val}'"
            polygons = list(poly_layer.getFeatures(QgsFeatureRequest().setFilterExpression(expr)))
            self.msg(f"Using filter '{expr}': Found {len(polygons)} polygons.")
            
        # Priority 3: All Polygons (Fallback)
        else:
            self.msg("No selection or filter. Processing ALL polygons (This may take time)...")
            polygons = list(poly_layer.getFeatures())

        if not polygons:
            self.msg("Error: No polygons found to process.")
            return

        all_daps = [] # Final list of new features

        for poly_feat in polygons:
            fdh_id = str(poly_feat[fdh_field]) if fdh_field else "UNK"
            geom_poly = poly_feat.geometry()
            bbox = geom_poly.boundingBox()
            
            self.msg(f"-> Processing Area: {fdh_id}")
            
            # 2. Extract Lines within this Polygon
            req = QgsFeatureRequest().setFilterRect(bbox)
            
            drops = [f for f in drop_layer.getFeatures(req) if f.geometry().intersects(geom_poly)]
            dists = [f for f in dist_layer.getFeatures(req) if f.geometry().intersects(geom_poly)]
            dconds = [f for f in dcond_layer.getFeatures(req) if f.geometry().intersects(geom_poly)]
            
            # SAFE SPATIAL INDEX CREATION
            dist_idx = QgsSpatialIndex()
            for f in dists:
                dist_idx.addFeature(f)
            dist_map = {f.id(): f for f in dists}
            
            # --- INTERSECTION LOGIC ---
            poly_daps = []
            occupied = set()

            # A. DAP-DROP: Drop Cable touches Distribution Conduit
            for drop in drops:
                g_drop = drop.geometry()
                cand_ids = dist_idx.intersects(g_drop.boundingBox())
                for cid in cand_ids:
                    dist = dist_map[cid]
                    if g_drop.intersects(dist.geometry()):
                        ix = g_drop.intersection(dist.geometry())
                        pts = self.get_geom_points(ix)
                        for pt in pts:
                            if not geom_poly.contains(QgsGeometry.fromPointXY(pt)): continue
                            key = (round(pt.x(), 3), round(pt.y(), 3))
                            if key not in occupied:
                                f = QgsFeature()
                                f.setGeometry(QgsGeometry.fromPointXY(pt))
                                f.setAttributes([fdh_id, "", "DAP-DROP"])
                                poly_daps.append(f)
                                occupied.add(key)

            # B. DAP-DROP: Distribution touches Drop Conduit
            for dc in dconds:
                g_dc = dc.geometry()
                cand_ids = dist_idx.intersects(g_dc.boundingBox())
                for cid in cand_ids:
                    dist = dist_map[cid]
                    if g_dc.intersects(dist.geometry()):
                        ix = g_dc.intersection(dist.geometry())
                        pts = self.get_geom_points(ix)
                        for pt in pts:
                            if not geom_poly.contains(QgsGeometry.fromPointXY(pt)): continue
                            key = (round(pt.x(), 3), round(pt.y(), 3))
                            if key not in occupied:
                                f = QgsFeature()
                                f.setGeometry(QgsGeometry.fromPointXY(pt))
                                f.setAttributes([fdh_id, "", "DAP-DROP"])
                                poly_daps.append(f)
                                occupied.add(key)

            # C. DAP-BRANCH: Conduit vs Conduit
            # C1. Dist vs Dist
            for i, d1 in enumerate(dists):
                g1 = d1.geometry()
                for j in range(i+1, len(dists)):
                    d2 = dists[j]
                    if g1.intersects(d2.geometry()):
                        ix = g1.intersection(d2.geometry())
                        pts = self.get_geom_points(ix)
                        for pt in pts:
                            if not geom_poly.contains(QgsGeometry.fromPointXY(pt)): continue
                            key = (round(pt.x(), 3), round(pt.y(), 3))
                            if key not in occupied:
                                f = QgsFeature()
                                f.setGeometry(QgsGeometry.fromPointXY(pt))
                                f.setAttributes([fdh_id, "", "DAP-BRANCH"])
                                poly_daps.append(f)
                                occupied.add(key)
                                
            # C2. DropCond vs DropCond
            for i, dc1 in enumerate(dconds):
                g1 = dc1.geometry()
                for j in range(i+1, len(dconds)):
                    dc2 = dconds[j]
                    if g1.intersects(dc2.geometry()):
                        ix = g1.intersection(dc2.geometry())
                        pts = self.get_geom_points(ix)
                        for pt in pts:
                            if not geom_poly.contains(QgsGeometry.fromPointXY(pt)): continue
                            key = (round(pt.x(), 3), round(pt.y(), 3))
                            if key not in occupied:
                                f = QgsFeature()
                                f.setGeometry(QgsGeometry.fromPointXY(pt))
                                f.setAttributes([fdh_id, "", "DAP-BRANCH"])
                                poly_daps.append(f)
                                occupied.add(key)

            # Sequence IDs
            seq = 1
            for feat in poly_daps:
                feat.setAttribute(1, f"{fdh_id}-DAP-{seq:02d}")
                seq += 1
            
            all_daps.extend(poly_daps)

        # 4. Write Output
        if self.chk_append.isChecked():
            target = self.combo_target.currentLayer()
            if target:
                self.write_to_layer(target, all_daps)
            else:
                self.msg("Error: No append layer selected.")
        else:
            self.create_memory_layer(all_daps, dist_layer.crs())

        self.msg(f"Finished. Generated {len(all_daps)} DAPs.")

    def get_geom_points(self, geom):
        pts = []
        if geom.wkbType() == QgsWkbTypes.Point:
            pts.append(geom.asPoint())
        elif geom.isMultipart():
            pts.extend(geom.asMultiPoint())
        return pts

    def create_memory_layer(self, features, crs):
        vl = QgsVectorLayer(f"Point?crs={crs.authid()}", "Proposed_DAPs", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("FDH_ID", QVariant.String),
            QgsField("ELEMENTID", QVariant.String),
            QgsField("TYPE", QVariant.String)
        ])
        vl.updateFields()
        pr.addFeatures(features)
        vl.updateExtents()
        QgsProject.instance().addMapLayer(vl)

    def write_to_layer(self, layer, features):
        layer.startEditing()
        f_map = {}
        for fname in ["FDH_ID", "ELEMENTID", "TYPE"]:
            idx = layer.fields().indexOf(fname)
            if idx == -1:
                layer.dataProvider().addAttributes([QgsField(fname, QVariant.String)])
                layer.updateFields()
                idx = layer.fields().indexOf(fname)
            f_map[fname] = idx
            
        final_feats = []
        for src_f in features:
            new_f = QgsFeature(layer.fields())
            new_f.setGeometry(src_f.geometry())
            new_f.setAttribute(f_map["FDH_ID"], src_f.attribute(0))
            new_f.setAttribute(f_map["ELEMENTID"], src_f.attribute(1))
            new_f.setAttribute(f_map["TYPE"], src_f.attribute(2))
            final_feats.append(new_f)
            
        layer.dataProvider().addFeatures(final_feats)
        layer.commitChanges()

# ========================== PLUGIN ENTRY POINT ==========================
class DapCreatorPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None

    def initGui(self):
        self.action = QAction(QIcon(""), "DAP Creation Tool", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Hexatronics", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&Hexatronics", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        if not self.dlg:
            self.dlg = DapCreatorDialog(self.iface)
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()